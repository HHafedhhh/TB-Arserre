/*
  # Création des tables pour l'application Suivi de Caisse

  1. Nouvelles Tables
    - `users` - Utilisateurs de l'application
    - `categories` - Catégories de transactions
    - `clients` - Clients de l'entreprise
    - `bank_accounts` - Comptes bancaires
    - `transactions` - Transactions financières
    - `client_orders` - Commandes des clients

  2. Sécurité
    - Activation de RLS sur toutes les tables
    - Politiques pour les utilisateurs authentifiés
*/

-- Table des utilisateurs
CREATE TABLE IF NOT EXISTS users (
  id text PRIMARY KEY,
  name text NOT NULL,
  role text NOT NULL CHECK (role IN ('admin', 'user')),
  balance decimal(10,2) DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Table des catégories
CREATE TABLE IF NOT EXISTS categories (
  id text PRIMARY KEY,
  name text NOT NULL,
  type text NOT NULL CHECK (type IN ('income', 'expense')),
  color text NOT NULL DEFAULT '#EF4444',
  subcategories jsonb DEFAULT '[]'::jsonb,
  parent_category text,
  created_at timestamptz DEFAULT now()
);

-- Table des clients
CREATE TABLE IF NOT EXISTS clients (
  id text PRIMARY KEY,
  name text NOT NULL,
  email text,
  phone text,
  address text,
  balance decimal(10,2) DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Table des comptes bancaires
CREATE TABLE IF NOT EXISTS bank_accounts (
  id text PRIMARY KEY,
  name text NOT NULL,
  account_number text NOT NULL,
  bank_name text NOT NULL,
  balance decimal(10,2) DEFAULT 0,
  currency text DEFAULT 'TND',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Table des commandes clients
CREATE TABLE IF NOT EXISTS client_orders (
  id text PRIMARY KEY,
  client_id text NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  order_number text NOT NULL,
  description text NOT NULL,
  amount decimal(10,2) NOT NULL,
  status text NOT NULL CHECK (status IN ('received', 'delivered', 'archived')),
  received_date timestamptz NOT NULL,
  delivered_date timestamptz,
  archived_date timestamptz,
  notes text,
  created_at timestamptz DEFAULT now()
);

-- Table des transactions
CREATE TABLE IF NOT EXISTS transactions (
  id text PRIMARY KEY,
  type text NOT NULL CHECK (type IN ('income', 'expense', 'transfer', 'bank_transfer')),
  amount decimal(10,2) NOT NULL,
  description text NOT NULL,
  category text NOT NULL,
  subcategory text,
  from_user text REFERENCES users(id),
  to_user text REFERENCES users(id),
  user_id text NOT NULL REFERENCES users(id),
  client_id text REFERENCES clients(id),
  bank_account_id text REFERENCES bank_accounts(id),
  order_id text REFERENCES client_orders(id),
  payment_method text NOT NULL CHECK (payment_method IN ('cash', 'bank', 'transfer')),
  date timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Activation de RLS sur toutes les tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE bank_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE client_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;

-- Politiques RLS pour les utilisateurs authentifiés
CREATE POLICY "Users can read all data" ON users FOR SELECT TO authenticated USING (true);
CREATE POLICY "Users can insert data" ON users FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Users can update data" ON users FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Users can delete data" ON users FOR DELETE TO authenticated USING (true);

CREATE POLICY "Categories can read all data" ON categories FOR SELECT TO authenticated USING (true);
CREATE POLICY "Categories can insert data" ON categories FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Categories can update data" ON categories FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Categories can delete data" ON categories FOR DELETE TO authenticated USING (true);

CREATE POLICY "Clients can read all data" ON clients FOR SELECT TO authenticated USING (true);
CREATE POLICY "Clients can insert data" ON clients FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Clients can update data" ON clients FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Clients can delete data" ON clients FOR DELETE TO authenticated USING (true);

CREATE POLICY "Bank accounts can read all data" ON bank_accounts FOR SELECT TO authenticated USING (true);
CREATE POLICY "Bank accounts can insert data" ON bank_accounts FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Bank accounts can update data" ON bank_accounts FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Bank accounts can delete data" ON bank_accounts FOR DELETE TO authenticated USING (true);

CREATE POLICY "Client orders can read all data" ON client_orders FOR SELECT TO authenticated USING (true);
CREATE POLICY "Client orders can insert data" ON client_orders FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Client orders can update data" ON client_orders FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Client orders can delete data" ON client_orders FOR DELETE TO authenticated USING (true);

CREATE POLICY "Transactions can read all data" ON transactions FOR SELECT TO authenticated USING (true);
CREATE POLICY "Transactions can insert data" ON transactions FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Transactions can update data" ON transactions FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Transactions can delete data" ON transactions FOR DELETE TO authenticated USING (true);

-- Index pour améliorer les performances
CREATE INDEX IF NOT EXISTS idx_transactions_user_id ON transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_client_id ON transactions(client_id);
CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(date);
CREATE INDEX IF NOT EXISTS idx_client_orders_client_id ON client_orders(client_id);
CREATE INDEX IF NOT EXISTS idx_client_orders_status ON client_orders(status);