/*
  # Insertion des données initiales

  1. Données de base
    - Utilisateurs par défaut
    - Catégories de base
    - Clients d'exemple
    - Comptes bancaires
    - Commandes clients
    - Transactions d'exemple

  2. Notes
    - Ces données servent d'exemple et peuvent être modifiées
    - Les IDs sont générés de manière cohérente
*/

-- Insertion des utilisateurs par défaut
INSERT INTO users (id, name, role, balance) VALUES
('1', 'Ahmed Ben Ali', 'admin', 2500.00),
('2', 'Fatima Karray', 'user', 1800.50),
('3', 'Mohamed Trabelsi', 'user', 950.25),
('4', 'Leila Hammami', 'user', 3200.75)
ON CONFLICT (id) DO NOTHING;

-- Insertion des catégories
INSERT INTO categories (id, name, type, color, subcategories, parent_category) VALUES
-- Catégories principales
('1', 'Sortie Argent', 'expense', '#EF4444', '[]'::jsonb, NULL),
('5', 'Entrée Argent', 'income', '#10B981', '[]'::jsonb, NULL),

-- Sous-catégories de sortie
('2', 'Achat', 'expense', '#F59E0B', '["Matières premières", "Équipements", "Fournitures bureau", "Marchandises"]'::jsonb, 'Sortie Argent'),
('3', 'Dépense', 'expense', '#EF4444', '["Loyer", "Électricité", "Eau", "Internet", "Téléphone", "Assurance", "Maintenance"]'::jsonb, 'Sortie Argent'),
('4', 'Salaire', 'expense', '#DC2626', '["Salaire fixe", "Heures supplémentaires", "Primes", "Charges sociales"]'::jsonb, 'Sortie Argent'),

-- Sous-catégories d''entrée
('6', 'Recouvrement Client', 'income', '#059669', '["Paiement facture", "Acompte", "Solde final", "Paiement retard"]'::jsonb, 'Entrée Argent'),
('7', 'Transfert entre user', 'income', '#3B82F6', '["Transfert interne", "Avance", "Remboursement"]'::jsonb, 'Entrée Argent'),
('8', 'Transfert Bancaire', 'income', '#8B5CF6', '["Dépôt en banque", "Retrait banque", "Virement reçu"]'::jsonb, 'Entrée Argent')
ON CONFLICT (id) DO NOTHING;

-- Insertion des clients
INSERT INTO clients (id, name, email, phone, address, balance) VALUES
('1', 'Société ABC', 'contact@abc.tn', '+216 71 123 456', 'Tunis, Tunisie', 1500.00),
('2', 'Client XYZ', 'xyz@email.tn', '+216 98 765 432', 'Sfax, Tunisie', -250.00)
ON CONFLICT (id) DO NOTHING;

-- Insertion des comptes bancaires
INSERT INTO bank_accounts (id, name, account_number, bank_name, balance, currency, is_active) VALUES
('1', 'Compte Principal', '12345678901234567890', 'Banque de Tunisie', 15000.00, 'TND', true),
('2', 'Compte Épargne', '09876543210987654321', 'BIAT', 8500.00, 'TND', true),
('3', 'Compte Devises', '11223344556677889900', 'Attijari Bank', 2200.00, 'EUR', true)
ON CONFLICT (id) DO NOTHING;

-- Insertion des commandes clients
INSERT INTO client_orders (id, client_id, order_number, description, amount, status, received_date, delivered_date, archived_date, notes) VALUES
('1', '1', 'CMD-2024-001', 'Commande matériel informatique', 2500.00, 'delivered', '2024-01-10', '2024-01-15', NULL, 'Livraison complète'),
('2', '1', 'CMD-2024-002', 'Fournitures bureau', 850.00, 'received', '2024-01-20', NULL, NULL, 'En attente de livraison'),
('3', '2', 'CMD-2024-003', 'Équipements industriels', 4200.00, 'delivered', '2024-01-05', '2024-01-12', NULL, 'Livraison partielle - reste 500 TND'),
('4', '2', 'CMD-2024-004', 'Maintenance équipements', 1200.00, 'archived', '2023-12-15', '2023-12-20', '2024-01-01', 'Commande archivée - paiement complet')
ON CONFLICT (id) DO NOTHING;

-- Insertion des transactions d'exemple
INSERT INTO transactions (id, type, amount, description, category, subcategory, from_user, to_user, user_id, client_id, bank_account_id, order_id, payment_method, date) VALUES
('1', 'income', 1500.00, 'Paiement facture client ABC en espèces', 'Recouvrement Client', 'Paiement facture', NULL, NULL, '1', '1', NULL, '1', 'cash', '2024-01-15 10:30:00'),
('2', 'expense', 250.00, 'Achat fournitures bureau en espèces', 'Achat', 'Fournitures bureau', NULL, NULL, '2', NULL, NULL, NULL, 'cash', '2024-01-14 18:45:00'),
('3', 'transfer', 500.00, 'Transfert vers Mohamed', 'Transfert entre user', 'Transfert interne', '1', '3', '1', NULL, NULL, NULL, 'transfer', '2024-01-13 14:20:00'),
('4', 'expense', 2200.00, 'Salaire mensuel équipe par virement', 'Salaire', 'Salaire fixe', NULL, NULL, '4', NULL, '1', NULL, 'bank', '2024-01-01 09:00:00'),
('5', 'expense', 180.00, 'Facture électricité en espèces', 'Dépense', 'Électricité', NULL, NULL, '3', NULL, NULL, NULL, 'cash', '2024-01-12 16:30:00'),
('6', 'income', 750.00, 'Acompte client XYZ par virement', 'Recouvrement Client', 'Acompte', NULL, NULL, '2', '2', '2', '3', 'bank', '2024-01-16 11:15:00'),
('7', 'bank_transfer', 1000.00, 'Dépôt espèces en banque', 'Transfert Bancaire', 'Dépôt en banque', NULL, NULL, '1', NULL, '1', NULL, 'transfer', '2024-01-17 09:30:00'),
('8', 'bank_transfer', 500.00, 'Retrait espèces de la banque', 'Transfert Bancaire', 'Retrait banque', NULL, NULL, '2', NULL, '2', NULL, 'transfer', '2024-01-18 14:15:00')
ON CONFLICT (id) DO NOTHING;