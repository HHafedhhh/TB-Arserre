import React, { useState, useEffect } from 'react';
import { BarChart3, Plus, List, Settings as SettingsIcon, Package, TrendingUp } from 'lucide-react';
import { Dashboard } from './components/Dashboard';
import { TransactionForm } from './components/TransactionForm';
import { TransactionList } from './components/TransactionList';
import { Settings } from './components/Settings';
import { ClientOrders } from './components/ClientOrders';
import { ClientRecoverySummary } from './components/ClientRecoverySummary';
import { DatabaseStatus } from './components/DatabaseStatus';
import { useSupabaseData } from './hooks/useSupabaseData';
import { users as initialUsers, transactions as initialTransactions, categories as initialCategories, clients as initialClients, bankAccounts as initialBankAccounts, clientOrders as initialClientOrders } from './data/mockData';
import { Transaction, User, Category, Client, BankAccount, ClientOrder } from './types';

type TabType = 'dashboard' | 'add' | 'list' | 'orders' | 'recovery' | 'settings';

function App() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  
  // Try to use Supabase, fallback to localStorage
  const supabaseData = useSupabaseData();
  const [useSupabase, setUseSupabase] = useState(false);
  
  // Local state for fallback
  const [localUsers, setLocalUsers] = useState<User[]>(initialUsers);
  const [localTransactions, setLocalTransactions] = useState<Transaction[]>(initialTransactions);
  const [localCategories, setLocalCategories] = useState<Category[]>(initialCategories);
  const [localClients, setLocalClients] = useState<Client[]>(initialClients);
  const [localBankAccounts, setLocalBankAccounts] = useState<BankAccount[]>(initialBankAccounts);
  const [localClientOrders, setLocalClientOrders] = useState<ClientOrder[]>(initialClientOrders);

  // Determine which data source to use
  const users = useSupabase ? supabaseData.users : localUsers;
  const transactions = useSupabase ? supabaseData.transactions : localTransactions;
  const categories = useSupabase ? supabaseData.categories : localCategories;
  const clients = useSupabase ? supabaseData.clients : localClients;
  const bankAccounts = useSupabase ? supabaseData.bankAccounts : localBankAccounts;
  const clientOrders = useSupabase ? supabaseData.clientOrders : localClientOrders;

  const setUsers = useSupabase ? supabaseData.setUsers : setLocalUsers;
  const setTransactions = useSupabase ? supabaseData.setTransactions : setLocalTransactions;
  const setCategories = useSupabase ? supabaseData.setCategories : setLocalCategories;
  const setClients = useSupabase ? supabaseData.setClients : setLocalClients;
  const setBankAccounts = useSupabase ? supabaseData.setBankAccounts : setLocalBankAccounts;
  const setClientOrders = useSupabase ? supabaseData.setClientOrders : setLocalClientOrders;

  // Check if Supabase is available and working
  useEffect(() => {
    const checkSupabase = async () => {
      try {
        // Check if environment variables are set
        const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
        const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
        
        if (supabaseUrl && supabaseKey && !supabaseData.error && !supabaseData.loading) {
          setUseSupabase(true);
          console.log('✅ Supabase connecté avec succès');
        } else {
          setUseSupabase(false);
          console.log('⚠️ Utilisation du mode hors ligne (localStorage)');
        }
      } catch (error) {
        setUseSupabase(false);
        console.log('⚠️ Erreur Supabase, basculement vers localStorage:', error);
      }
    };

    checkSupabase();
  }, [supabaseData.error, supabaseData.loading]);
  // Load data from localStorage on app start
  useEffect(() => {
    if (useSupabase) return; // Skip localStorage if using Supabase
    
    try {
      const savedUsers = localStorage.getItem('cashflow-users');
      const savedTransactions = localStorage.getItem('cashflow-transactions');
      const savedCategories = localStorage.getItem('cashflow-categories');
      const savedClients = localStorage.getItem('cashflow-clients');
      const savedBankAccounts = localStorage.getItem('cashflow-bank-accounts');
      const savedClientOrders = localStorage.getItem('cashflow-client-orders');
      
      console.log('🔄 Chargement des données depuis localStorage...');
      console.log('Users:', savedUsers ? 'Trouvé' : 'Non trouvé');
      console.log('Transactions:', savedTransactions ? 'Trouvé' : 'Non trouvé');
      console.log('Categories:', savedCategories ? 'Trouvé' : 'Non trouvé');
      console.log('Clients:', savedClients ? 'Trouvé' : 'Non trouvé');
      console.log('Bank Accounts:', savedBankAccounts ? 'Trouvé' : 'Non trouvé');
      console.log('Client Orders:', savedClientOrders ? 'Trouvé' : 'Non trouvé');
    
      if (savedUsers) {
        const parsedUsers = JSON.parse(savedUsers);
        console.log('✅ Utilisateurs chargés:', parsedUsers.length);
        setLocalUsers(parsedUsers);
      } else {
        console.log('⚠️ Aucun utilisateur sauvegardé, utilisation des données par défaut');
        setLocalUsers(initialUsers);
        localStorage.setItem('cashflow-users', JSON.stringify(initialUsers));
      }
    
      if (savedTransactions) {
        const parsedTransactions = JSON.parse(savedTransactions).map((t: any) => ({
          ...t,
          date: new Date(t.date),
          createdAt: new Date(t.createdAt),
          paymentMethod: t.paymentMethod || 'cash' // Default for old transactions
        }));
        console.log('✅ Transactions chargées:', parsedTransactions.length);
        setLocalTransactions(parsedTransactions);
      } else {
        console.log('⚠️ Aucune transaction sauvegardée, utilisation des données par défaut');
        setLocalTransactions(initialTransactions);
        localStorage.setItem('cashflow-transactions', JSON.stringify(initialTransactions));
      }

      if (savedCategories) {
        const parsedCategories = JSON.parse(savedCategories);
        console.log('✅ Catégories chargées:', parsedCategories.length);
        setLocalCategories(parsedCategories);
      } else {
        console.log('⚠️ Aucune catégorie sauvegardée, utilisation des données par défaut');
        setLocalCategories(initialCategories);
        localStorage.setItem('cashflow-categories', JSON.stringify(initialCategories));
      }

      if (savedClients) {
        const parsedClients = JSON.parse(savedClients).map((c: any) => ({
          ...c,
          createdAt: new Date(c.createdAt)
        }));
        console.log('✅ Clients chargés:', parsedClients.length);
        setLocalClients(parsedClients);
      } else {
        console.log('⚠️ Aucun client sauvegardé, utilisation des données par défaut');
        setLocalClients(initialClients);
        localStorage.setItem('cashflow-clients', JSON.stringify(initialClients));
      }

      if (savedBankAccounts) {
        const parsedBankAccounts = JSON.parse(savedBankAccounts).map((b: any) => ({
          ...b,
          createdAt: new Date(b.createdAt)
        }));
        console.log('✅ Comptes bancaires chargés:', parsedBankAccounts.length);
        setLocalBankAccounts(parsedBankAccounts);
      } else {
        console.log('⚠️ Aucun compte bancaire sauvegardé, utilisation des données par défaut');
        setLocalBankAccounts(initialBankAccounts);
        localStorage.setItem('cashflow-bank-accounts', JSON.stringify(initialBankAccounts));
      }

      if (savedClientOrders) {
        const parsedClientOrders = JSON.parse(savedClientOrders).map((o: any) => ({
          ...o,
          receivedDate: new Date(o.receivedDate),
          deliveredDate: o.deliveredDate ? new Date(o.deliveredDate) : undefined,
          archivedDate: o.archivedDate ? new Date(o.archivedDate) : undefined,
          createdAt: new Date(o.createdAt)
        }));
        console.log('✅ Commandes clients chargées:', parsedClientOrders.length);
        setLocalClientOrders(parsedClientOrders);
      } else {
        console.log('⚠️ Aucune commande client sauvegardée, utilisation des données par défaut');
        setLocalClientOrders(initialClientOrders);
        localStorage.setItem('cashflow-client-orders', JSON.stringify(initialClientOrders));
      }
      
      console.log('✅ Chargement des données terminé');
    } catch (error) {
      console.error('❌ Erreur lors du chargement des données:', error);
      // En cas d'erreur, utiliser les données par défaut
      setLocalUsers(initialUsers);
      setLocalTransactions(initialTransactions);
      setLocalCategories(initialCategories);
      setLocalClients(initialClients);
      setLocalBankAccounts(initialBankAccounts);
      setLocalClientOrders(initialClientOrders);
    }
  }, [useSupabase]);

  // Save data to localStorage whenever it changes
  useEffect(() => {
    if (useSupabase) return; // Skip localStorage if using Supabase
    try {
      console.log('💾 Sauvegarde des utilisateurs:', users.length);
      localStorage.setItem('cashflow-users', JSON.stringify(users));
    } catch (error) {
      console.error('❌ Erreur sauvegarde utilisateurs:', error);
    }
  }, [users, useSupabase]);

  useEffect(() => {
    if (useSupabase) return;
    try {
      console.log('💾 Sauvegarde des transactions:', transactions.length);
      localStorage.setItem('cashflow-transactions', JSON.stringify(transactions));
    } catch (error) {
      console.error('❌ Erreur sauvegarde transactions:', error);
    }
  }, [transactions, useSupabase]);

  useEffect(() => {
    if (useSupabase) return;
    try {
      console.log('💾 Sauvegarde des catégories:', categories.length);
      localStorage.setItem('cashflow-categories', JSON.stringify(categories));
    } catch (error) {
      console.error('❌ Erreur sauvegarde catégories:', error);
    }
  }, [categories, useSupabase]);

  useEffect(() => {
    if (useSupabase) return;
    try {
      console.log('💾 Sauvegarde des clients:', clients.length);
      localStorage.setItem('cashflow-clients', JSON.stringify(clients));
    } catch (error) {
      console.error('❌ Erreur sauvegarde clients:', error);
    }
  }, [clients, useSupabase]);

  useEffect(() => {
    if (useSupabase) return;
    try {
      console.log('💾 Sauvegarde des comptes bancaires:', bankAccounts.length);
      localStorage.setItem('cashflow-bank-accounts', JSON.stringify(bankAccounts));
    } catch (error) {
      console.error('❌ Erreur sauvegarde comptes bancaires:', error);
    }
  }, [bankAccounts, useSupabase]);

  useEffect(() => {
    if (useSupabase) return;
    try {
      console.log('💾 Sauvegarde des commandes clients:', clientOrders.length);
      localStorage.setItem('cashflow-client-orders', JSON.stringify(clientOrders));
    } catch (error) {
      console.error('❌ Erreur sauvegarde commandes clients:', error);
    }
  }, [clientOrders, useSupabase]);

  const handleAddTransaction = (transactionData: Omit<Transaction, 'id' | 'createdAt'>) => {
    const newTransaction: Transaction = {
      ...transactionData,
      id: Date.now().toString(),
      createdAt: new Date()
    };

    if (useSupabase) {
      // Save to Supabase
      supabaseData.saveTransaction(newTransaction).catch(console.error);
    }
    
    setTransactions(prev => [newTransaction, ...prev]);

    // Update balances based on transaction type and payment method
    if (transactionData.type === 'income') {
      // Only update user balance for cash transactions
      if (transactionData.paymentMethod === 'cash') {
        setUsers(prev => prev.map(user => 
          user.id === transactionData.userId 
            ? { ...user, balance: user.balance + transactionData.amount }
            : user
        ));
      }
      
      // Update client balance if applicable
      if (transactionData.clientId) {
        setClients(prev => prev.map(client => 
          client.id === transactionData.clientId 
            ? { ...client, balance: client.balance - transactionData.amount }
            : client
        ));
      }

      // Update bank account balance if applicable
      if (transactionData.bankAccountId) {
        setBankAccounts(prev => prev.map(account => 
          account.id === transactionData.bankAccountId 
            ? { ...account, balance: account.balance + transactionData.amount }
            : account
        ));
      }
    } else if (transactionData.type === 'expense') {
      // Only update user balance for cash transactions
      if (transactionData.paymentMethod === 'cash') {
        setUsers(prev => prev.map(user => 
          user.id === transactionData.userId 
            ? { ...user, balance: user.balance - transactionData.amount }
            : user
        ));
      }

      // Update bank account balance if applicable (for bank payments)
      if (transactionData.bankAccountId) {
        setBankAccounts(prev => prev.map(account => 
          account.id === transactionData.bankAccountId 
            ? { ...account, balance: account.balance - transactionData.amount }
            : account
        ));
      }
    } else if (transactionData.type === 'transfer') {
      // User to user transfers affect cash balances
      setUsers(prev => prev.map(user => {
        if (user.id === transactionData.fromUser) {
          return { ...user, balance: user.balance - transactionData.amount };
        } else if (user.id === transactionData.toUser) {
          return { ...user, balance: user.balance + transactionData.amount };
        }
        return user;
      }));
    } else if (transactionData.type === 'bank_transfer') {
      // Bank transfers: cash to bank or bank to cash
      if (transactionData.subcategory === 'Dépôt en banque') {
        // Remove from user cash, add to bank
        setUsers(prev => prev.map(user => 
          user.id === transactionData.userId 
            ? { ...user, balance: user.balance - transactionData.amount }
            : user
        ));
        setBankAccounts(prev => prev.map(account => 
          account.id === transactionData.bankAccountId 
            ? { ...account, balance: account.balance + transactionData.amount }
            : account
        ));
      } else if (transactionData.subcategory === 'Retrait banque') {
        // Remove from bank, add to user cash
        setUsers(prev => prev.map(user => 
          user.id === transactionData.userId 
            ? { ...user, balance: user.balance + transactionData.amount }
            : user
        ));
        setBankAccounts(prev => prev.map(account => 
          account.id === transactionData.bankAccountId 
            ? { ...account, balance: account.balance - transactionData.amount }
            : account
        ));
      }
    }
  };

  const handleUpdateTransaction = (updatedTransaction: Transaction) => {
    const originalTransaction = transactions.find(t => t.id === updatedTransaction.id);
    if (!originalTransaction) return;

    // Revert original transaction effects on balances
    if (originalTransaction.type === 'income') {
      if (originalTransaction.paymentMethod === 'cash') {
        setUsers(prev => prev.map(user => 
          user.id === originalTransaction.userId 
            ? { ...user, balance: user.balance - originalTransaction.amount }
            : user
        ));
      }
      
      if (originalTransaction.clientId) {
        setClients(prev => prev.map(client => 
          client.id === originalTransaction.clientId 
            ? { ...client, balance: client.balance + originalTransaction.amount }
            : client
        ));
      }

      if (originalTransaction.bankAccountId) {
        setBankAccounts(prev => prev.map(account => 
          account.id === originalTransaction.bankAccountId 
            ? { ...account, balance: account.balance - originalTransaction.amount }
            : account
        ));
      }
    } else if (originalTransaction.type === 'expense') {
      if (originalTransaction.paymentMethod === 'cash') {
        setUsers(prev => prev.map(user => 
          user.id === originalTransaction.userId 
            ? { ...user, balance: user.balance + originalTransaction.amount }
            : user
        ));
      }

      if (originalTransaction.bankAccountId) {
        setBankAccounts(prev => prev.map(account => 
          account.id === originalTransaction.bankAccountId 
            ? { ...account, balance: account.balance + originalTransaction.amount }
            : account
        ));
      }
    } else if (originalTransaction.type === 'transfer') {
      setUsers(prev => prev.map(user => {
        if (user.id === originalTransaction.fromUser) {
          return { ...user, balance: user.balance + originalTransaction.amount };
        } else if (user.id === originalTransaction.toUser) {
          return { ...user, balance: user.balance - originalTransaction.amount };
        }
        return user;
      }));
    } else if (originalTransaction.type === 'bank_transfer') {
      if (originalTransaction.subcategory === 'Dépôt en banque') {
        setUsers(prev => prev.map(user => 
          user.id === originalTransaction.userId 
            ? { ...user, balance: user.balance + originalTransaction.amount }
            : user
        ));
        setBankAccounts(prev => prev.map(account => 
          account.id === originalTransaction.bankAccountId 
            ? { ...account, balance: account.balance - originalTransaction.amount }
            : account
        ));
      } else if (originalTransaction.subcategory === 'Retrait banque') {
        setUsers(prev => prev.map(user => 
          user.id === originalTransaction.userId 
            ? { ...user, balance: user.balance - originalTransaction.amount }
            : user
        ));
        setBankAccounts(prev => prev.map(account => 
          account.id === originalTransaction.bankAccountId 
            ? { ...account, balance: account.balance + originalTransaction.amount }
            : account
        ));
      }
    }

    // Apply new transaction effects on balances
    if (updatedTransaction.type === 'income') {
      if (updatedTransaction.paymentMethod === 'cash') {
        setUsers(prev => prev.map(user => 
          user.id === updatedTransaction.userId 
            ? { ...user, balance: user.balance + updatedTransaction.amount }
            : user
        ));
      }
      
      if (updatedTransaction.clientId) {
        setClients(prev => prev.map(client => 
          client.id === updatedTransaction.clientId 
            ? { ...client, balance: client.balance - updatedTransaction.amount }
            : client
        ));
      }

      if (updatedTransaction.bankAccountId) {
        setBankAccounts(prev => prev.map(account => 
          account.id === updatedTransaction.bankAccountId 
            ? { ...account, balance: account.balance + updatedTransaction.amount }
            : account
        ));
      }
    } else if (updatedTransaction.type === 'expense') {
      if (updatedTransaction.paymentMethod === 'cash') {
        setUsers(prev => prev.map(user => 
          user.id === updatedTransaction.userId 
            ? { ...user, balance: user.balance - updatedTransaction.amount }
            : user
        ));
      }

      if (updatedTransaction.bankAccountId) {
        setBankAccounts(prev => prev.map(account => 
          account.id === updatedTransaction.bankAccountId 
            ? { ...account, balance: account.balance - updatedTransaction.amount }
            : account
        ));
      }
    } else if (updatedTransaction.type === 'transfer') {
      setUsers(prev => prev.map(user => {
        if (user.id === updatedTransaction.fromUser) {
          return { ...user, balance: user.balance - updatedTransaction.amount };
        } else if (user.id === updatedTransaction.toUser) {
          return { ...user, balance: user.balance + updatedTransaction.amount };
        }
        return user;
      }));
    } else if (updatedTransaction.type === 'bank_transfer') {
      if (updatedTransaction.subcategory === 'Dépôt en banque') {
        setUsers(prev => prev.map(user => 
          user.id === updatedTransaction.userId 
            ? { ...user, balance: user.balance - updatedTransaction.amount }
            : user
        ));
        setBankAccounts(prev => prev.map(account => 
          account.id === updatedTransaction.bankAccountId 
            ? { ...account, balance: account.balance + updatedTransaction.amount }
            : account
        ));
      } else if (updatedTransaction.subcategory === 'Retrait banque') {
        setUsers(prev => prev.map(user => 
          user.id === updatedTransaction.userId 
            ? { ...user, balance: user.balance + updatedTransaction.amount }
            : user
        ));
        setBankAccounts(prev => prev.map(account => 
          account.id === updatedTransaction.bankAccountId 
            ? { ...account, balance: account.balance - updatedTransaction.amount }
            : account
        ));
      }
    }

    // Update the transaction
    setTransactions(prev => prev.map(t => t.id === updatedTransaction.id ? updatedTransaction : t));
  };

  const handleDeleteTransaction = (transactionId: string) => {
    const transaction = transactions.find(t => t.id === transactionId);
    if (!transaction) return;

    // Revert transaction effects on balances
    if (transaction.type === 'income') {
      if (transaction.paymentMethod === 'cash') {
        setUsers(prev => prev.map(user => 
          user.id === transaction.userId 
            ? { ...user, balance: user.balance - transaction.amount }
            : user
        ));
      }
      
      if (transaction.clientId) {
        setClients(prev => prev.map(client => 
          client.id === transaction.clientId 
            ? { ...client, balance: client.balance + transaction.amount }
            : client
        ));
      }

      if (transaction.bankAccountId) {
        setBankAccounts(prev => prev.map(account => 
          account.id === transaction.bankAccountId 
            ? { ...account, balance: account.balance - transaction.amount }
            : account
        ));
      }
    } else if (transaction.type === 'expense') {
      if (transaction.paymentMethod === 'cash') {
        setUsers(prev => prev.map(user => 
          user.id === transaction.userId 
            ? { ...user, balance: user.balance + transaction.amount }
            : user
        ));
      }

      if (transaction.bankAccountId) {
        setBankAccounts(prev => prev.map(account => 
          account.id === transaction.bankAccountId 
            ? { ...account, balance: account.balance + transaction.amount }
            : account
        ));
      }
    } else if (transaction.type === 'transfer') {
      setUsers(prev => prev.map(user => {
        if (user.id === transaction.fromUser) {
          return { ...user, balance: user.balance + transaction.amount };
        } else if (user.id === transaction.toUser) {
          return { ...user, balance: user.balance - transaction.amount };
        }
        return user;
      }));
    } else if (transaction.type === 'bank_transfer') {
      if (transaction.subcategory === 'Dépôt en banque') {
        setUsers(prev => prev.map(user => 
          user.id === transaction.userId 
            ? { ...user, balance: user.balance + transaction.amount }
            : user
        ));
        setBankAccounts(prev => prev.map(account => 
          account.id === transaction.bankAccountId 
            ? { ...account, balance: account.balance - transaction.amount }
            : account
        ));
      } else if (transaction.subcategory === 'Retrait banque') {
        setUsers(prev => prev.map(user => 
          user.id === transaction.userId 
            ? { ...user, balance: user.balance - transaction.amount }
            : user
        ));
        setBankAccounts(prev => prev.map(account => 
          account.id === transaction.bankAccountId 
            ? { ...account, balance: account.balance + transaction.amount }
            : account
        ));
      }
    }

    // Remove the transaction
    setTransactions(prev => prev.filter(t => t.id !== transactionId));
  };

  const tabs = [
    { id: 'dashboard', label: 'Tableau de Bord', icon: BarChart3 },
    { id: 'add', label: 'Ajouter', icon: Plus },
    { id: 'list', label: 'Transactions', icon: List },
    { id: 'orders', label: 'Commandes', icon: Package },
    { id: 'recovery', label: 'Recouvrement', icon: TrendingUp },
    { id: 'settings', label: 'Paramètres', icon: SettingsIcon },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Database Status Indicator */}
      <DatabaseStatus 
        isConnected={useSupabase && !supabaseData.error}
        loading={supabaseData.loading}
        error={supabaseData.error}
      />
      
      {/* Mobile-first container */}
      <div className="w-full max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 py-2 sm:py-4 lg:py-8">
        {/* Header - Optimized for mobile */}
        <div className="mb-4 sm:mb-6 lg:mb-8">
          {/* Mobile: Logo en dessous du titre */}
          <div className="block lg:hidden text-center">
            <h1 className="text-xl sm:text-2xl font-bold text-gray-800 mb-3">
              Suivi de Caisse
            </h1>
            <div className="flex justify-center">
              <img 
                src="/Arserre - Copie (2).png" 
                alt="Arserre Logo" 
                className="h-8 sm:h-12 object-contain mix-blend-multiply"
                style={{ filter: 'drop-shadow(0 0 0 transparent)' }}
              />
            </div>
          </div>

          {/* Desktop: Logo à gauche, titre au centre */}
          <div className="hidden lg:block relative">
            {/* Logo à gauche */}
            <div className="absolute left-0 top-1/2 transform -translate-y-1/2">
              <img 
                src="/Arserre - Copie (2).png" 
                alt="Arserre Logo" 
                className="h-16 object-contain mix-blend-multiply"
                style={{ filter: 'drop-shadow(0 0 0 transparent)' }}
              />
            </div>
            
            {/* Titre centré */}
            <div className="text-center">
              <h1 className="text-4xl font-bold text-gray-800">
                Suivi de Caisse
              </h1>
            </div>
          </div>
        </div>

        {/* Navigation - Mobile-first design */}
        <div className="bg-white rounded-lg sm:rounded-xl shadow-lg p-1 sm:p-2 mb-4 sm:mb-6 lg:mb-8">
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-1 sm:gap-2">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabType)}
                className={`flex flex-col sm:flex-row items-center justify-center px-1 sm:px-3 lg:px-6 py-2 sm:py-3 rounded-md sm:rounded-lg font-medium transition-all duration-200 text-xs sm:text-sm lg:text-base ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <tab.icon className="w-4 h-4 sm:w-5 sm:h-5 mb-1 sm:mb-0 sm:mr-2" />
                <span className="text-xs sm:text-sm lg:text-base leading-tight">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="space-y-4 sm:space-y-6">
          {activeTab === 'dashboard' && (
            <Dashboard users={users} transactions={transactions} clients={clients} bankAccounts={bankAccounts} />
          )}
          
          {activeTab === 'add' && (
            <TransactionForm 
              users={users} 
              categories={categories} 
              clients={clients}
              bankAccounts={bankAccounts}
              onAddTransaction={handleAddTransaction}
            />
          )}
          
          {activeTab === 'list' && (
            <TransactionList 
              transactions={transactions} 
              users={users} 
              categories={categories}
              clients={clients}
              bankAccounts={bankAccounts}
              onUpdateTransaction={handleUpdateTransaction}
              onDeleteTransaction={handleDeleteTransaction}
            />
          )}

          {activeTab === 'orders' && (
            <ClientOrders 
              orders={clientOrders}
              clients={clients}
              onUpdateOrders={setClientOrders}
            />
          )}

          {activeTab === 'recovery' && (
            <ClientRecoverySummary 
              transactions={transactions}
              clients={clients}
              orders={clientOrders}
            />
          )}

          {activeTab === 'settings' && (
            <Settings 
              users={users}
              categories={categories}
              clients={clients}
              bankAccounts={bankAccounts}
              onUpdateUsers={setUsers}
              onUpdateCategories={setCategories}
              onUpdateClients={setClients}
              onUpdateBankAccounts={setBankAccounts}
            />
          )}
        </div>
      </div>
    </div>
  );
}

export default App;