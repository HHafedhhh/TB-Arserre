import { User, Transaction, Category, Client, BankAccount, ClientOrder } from '../types';

export const users: User[] = [
  { id: '1', name: 'Ahmed Ben Ali', role: 'admin', balance: 2500.00 },
  { id: '2', name: 'Fatima Karray', role: 'user', balance: 1800.50 },
  { id: '3', name: 'Mohamed Trabelsi', role: 'user', balance: 950.25 },
  { id: '4', name: 'Leila Hammami', role: 'user', balance: 3200.75 },
];

export const clients: Client[] = [
  { 
    id: '1', 
    name: 'Société ABC', 
    email: 'contact@abc.tn', 
    phone: '+216 71 123 456',
    address: 'Tunis, Tunisie',
    balance: 1500.00,
    createdAt: new Date('2024-01-01')
  },
  { 
    id: '2', 
    name: 'Client XYZ', 
    email: 'xyz@email.tn', 
    phone: '+216 98 765 432',
    address: 'Sfax, Tunisie',
    balance: -250.00,
    createdAt: new Date('2024-01-15')
  },
];

export const clientOrders: ClientOrder[] = [
  {
    id: '1',
    clientId: '1',
    orderNumber: 'CMD-2024-001',
    description: 'Commande matériel informatique',
    amount: 2500.00,
    status: 'delivered',
    receivedDate: new Date('2024-01-10'),
    deliveredDate: new Date('2024-01-15'),
    notes: 'Livraison complète',
    createdAt: new Date('2024-01-10')
  },
  {
    id: '2',
    clientId: '1',
    orderNumber: 'CMD-2024-002',
    description: 'Fournitures bureau',
    amount: 850.00,
    status: 'received',
    receivedDate: new Date('2024-01-20'),
    notes: 'En attente de livraison',
    createdAt: new Date('2024-01-20')
  },
  {
    id: '3',
    clientId: '2',
    orderNumber: 'CMD-2024-003',
    description: 'Équipements industriels',
    amount: 4200.00,
    status: 'delivered',
    receivedDate: new Date('2024-01-05'),
    deliveredDate: new Date('2024-01-12'),
    notes: 'Livraison partielle - reste 500 TND',
    createdAt: new Date('2024-01-05')
  },
  {
    id: '4',
    clientId: '2',
    orderNumber: 'CMD-2024-004',
    description: 'Maintenance équipements',
    amount: 1200.00,
    status: 'archived',
    receivedDate: new Date('2023-12-15'),
    deliveredDate: new Date('2023-12-20'),
    archivedDate: new Date('2024-01-01'),
    notes: 'Commande archivée - paiement complet',
    createdAt: new Date('2023-12-15')
  }
];

export const bankAccounts: BankAccount[] = [
  {
    id: '1',
    name: 'Compte Principal',
    accountNumber: '12345678901234567890',
    bankName: 'Banque de Tunisie',
    balance: 15000.00,
    currency: 'TND',
    isActive: true,
    createdAt: new Date('2024-01-01')
  },
  {
    id: '2',
    name: 'Compte Épargne',
    accountNumber: '09876543210987654321',
    bankName: 'BIAT',
    balance: 8500.00,
    currency: 'TND',
    isActive: true,
    createdAt: new Date('2024-01-01')
  },
  {
    id: '3',
    name: 'Compte Devises',
    accountNumber: '11223344556677889900',
    bankName: 'Attijari Bank',
    balance: 2200.00,
    currency: 'EUR',
    isActive: true,
    createdAt: new Date('2024-01-01')
  }
];

export const categories: Category[] = [
  // Sortie Argent (Dépenses)
  { 
    id: '1', 
    name: 'Sortie Argent', 
    type: 'expense', 
    color: '#EF4444',
    subcategories: []
  },
  { 
    id: '2', 
    name: 'Achat', 
    type: 'expense', 
    color: '#F59E0B',
    parentCategory: 'Sortie Argent',
    subcategories: ['Matières premières', 'Équipements', 'Fournitures bureau', 'Marchandises']
  },
  { 
    id: '3', 
    name: 'Dépense', 
    type: 'expense', 
    color: '#EF4444',
    parentCategory: 'Sortie Argent',
    subcategories: ['Loyer', 'Électricité', 'Eau', 'Internet', 'Téléphone', 'Assurance', 'Maintenance']
  },
  { 
    id: '4', 
    name: 'Salaire', 
    type: 'expense', 
    color: '#DC2626',
    parentCategory: 'Sortie Argent',
    subcategories: ['Salaire fixe', 'Heures supplémentaires', 'Primes', 'Charges sociales']
  },
  
  // Entrée Argent (Revenus)
  { 
    id: '5', 
    name: 'Entrée Argent', 
    type: 'income', 
    color: '#10B981',
    subcategories: []
  },
  { 
    id: '6', 
    name: 'Recouvrement Client', 
    type: 'income', 
    color: '#059669',
    parentCategory: 'Entrée Argent',
    subcategories: ['Paiement facture', 'Acompte', 'Solde final', 'Paiement retard']
  },
  { 
    id: '7', 
    name: 'Transfert entre user', 
    type: 'income', 
    color: '#3B82F6',
    parentCategory: 'Entrée Argent',
    subcategories: ['Transfert interne', 'Avance', 'Remboursement']
  },
  { 
    id: '8', 
    name: 'Transfert Bancaire', 
    type: 'income', 
    color: '#8B5CF6',
    parentCategory: 'Entrée Argent',
    subcategories: ['Dépôt en banque', 'Retrait banque', 'Virement reçu']
  },
];

export const transactions: Transaction[] = [
  {
    id: '1',
    type: 'income',
    amount: 1500.00,
    description: 'Paiement facture client ABC en espèces',
    category: 'Recouvrement Client',
    subcategory: 'Paiement facture',
    userId: '1',
    clientId: '1',
    orderId: '1',
    paymentMethod: 'cash',
    date: new Date('2024-01-15'),
    createdAt: new Date('2024-01-15T10:30:00')
  },
  {
    id: '2',
    type: 'expense',
    amount: 250.00,
    description: 'Achat fournitures bureau en espèces',
    category: 'Achat',
    subcategory: 'Fournitures bureau',
    userId: '2',
    paymentMethod: 'cash',
    date: new Date('2024-01-14'),
    createdAt: new Date('2024-01-14T18:45:00')
  },
  {
    id: '3',
    type: 'transfer',
    amount: 500.00,
    description: 'Transfert vers Mohamed',
    category: 'Transfert entre user',
    subcategory: 'Transfert interne',
    fromUser: '1',
    toUser: '3',
    userId: '1',
    paymentMethod: 'transfer',
    date: new Date('2024-01-13'),
    createdAt: new Date('2024-01-13T14:20:00')
  },
  {
    id: '4',
    type: 'expense',
    amount: 2200.00,
    description: 'Salaire mensuel équipe par virement',
    category: 'Salaire',
    subcategory: 'Salaire fixe',
    userId: '4',
    bankAccountId: '1',
    paymentMethod: 'bank',
    date: new Date('2024-01-01'),
    createdAt: new Date('2024-01-01T09:00:00')
  },
  {
    id: '5',
    type: 'expense',
    amount: 180.00,
    description: 'Facture électricité en espèces',
    category: 'Dépense',
    subcategory: 'Électricité',
    userId: '3',
    paymentMethod: 'cash',
    date: new Date('2024-01-12'),
    createdAt: new Date('2024-01-12T16:30:00')
  },
  {
    id: '6',
    type: 'income',
    amount: 750.00,
    description: 'Acompte client XYZ par virement',
    category: 'Recouvrement Client',
    subcategory: 'Acompte',
    userId: '2',
    clientId: '2',
    bankAccountId: '2',
    orderId: '3',
    paymentMethod: 'bank',
    date: new Date('2024-01-16'),
    createdAt: new Date('2024-01-16T11:15:00')
  },
  {
    id: '7',
    type: 'bank_transfer',
    amount: 1000.00,
    description: 'Dépôt espèces en banque',
    category: 'Transfert Bancaire',
    subcategory: 'Dépôt en banque',
    userId: '1',
    bankAccountId: '1',
    paymentMethod: 'transfer',
    date: new Date('2024-01-17'),
    createdAt: new Date('2024-01-17T09:30:00')
  },
  {
    id: '8',
    type: 'bank_transfer',
    amount: 500.00,
    description: 'Retrait espèces de la banque',
    category: 'Transfert Bancaire',
    subcategory: 'Retrait banque',
    userId: '2',
    bankAccountId: '2',
    paymentMethod: 'transfer',
    date: new Date('2024-01-18'),
    createdAt: new Date('2024-01-18T14:15:00')
  }
];