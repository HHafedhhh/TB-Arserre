export interface User {
  id: string;
  name: string;
  role: 'admin' | 'user';
  balance: number;
}

export interface Client {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  address?: string;
  balance: number;
  createdAt: Date;
}

export interface BankAccount {
  id: string;
  name: string;
  accountNumber: string;
  bankName: string;
  balance: number;
  currency: string;
  isActive: boolean;
  createdAt: Date;
}

export interface ClientOrder {
  id: string;
  clientId: string;
  orderNumber: string;
  description: string;
  amount: number;
  status: 'received' | 'delivered' | 'archived';
  receivedDate: Date;
  deliveredDate?: Date;
  archivedDate?: Date;
  notes?: string;
  createdAt: Date;
}

export interface Transaction {
  id: string;
  type: 'income' | 'expense' | 'transfer' | 'bank_transfer';
  amount: number;
  description: string;
  category: string;
  subcategory?: string;
  fromUser?: string;
  toUser?: string;
  userId: string;
  clientId?: string;
  bankAccountId?: string;
  orderId?: string;
  paymentMethod: 'cash' | 'bank' | 'transfer';
  date: Date;
  createdAt: Date;
}

export interface Category {
  id: string;
  name: string;
  type: 'income' | 'expense';
  subcategories?: string[];
  color: string;
  parentCategory?: string;
}

export interface FilterOptions {
  startDate?: Date;
  endDate?: Date;
  year?: number;
  month?: number;
  type?: 'income' | 'expense' | 'transfer' | 'bank_transfer' | 'all';
  userId?: string;
  category?: string;
  clientId?: string;
  bankAccountId?: string;
  paymentMethod?: 'cash' | 'bank' | 'transfer' | 'all';
}

export interface ClientRecoverySummary {
  clientId: string;
  clientName: string;
  totalOrders: number;
  totalOrderAmount: number;
  totalRecovered: number;
  totalPending: number;
  recoveryRate: number;
  lastRecoveryDate?: Date;
  orders: ClientOrder[];
  recoveries: Transaction[];
}