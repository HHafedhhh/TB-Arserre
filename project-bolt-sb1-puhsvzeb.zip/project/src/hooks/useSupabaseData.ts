import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { User, Transaction, Category, Client, BankAccount, ClientOrder } from '../types';

export const useSupabaseData = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([]);
  const [clientOrders, setClientOrders] = useState<ClientOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load data from Supabase
  const loadData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Load all data in parallel
      const [
        usersResult,
        transactionsResult,
        categoriesResult,
        clientsResult,
        bankAccountsResult,
        clientOrdersResult
      ] = await Promise.all([
        supabase.from('users').select('*'),
        supabase.from('transactions').select('*'),
        supabase.from('categories').select('*'),
        supabase.from('clients').select('*'),
        supabase.from('bank_accounts').select('*'),
        supabase.from('client_orders').select('*')
      ]);

      // Handle errors
      if (usersResult.error) throw usersResult.error;
      if (transactionsResult.error) throw transactionsResult.error;
      if (categoriesResult.error) throw categoriesResult.error;
      if (clientsResult.error) throw clientsResult.error;
      if (bankAccountsResult.error) throw bankAccountsResult.error;
      if (clientOrdersResult.error) throw clientOrdersResult.error;

      // Set data with proper date parsing
      setUsers(usersResult.data || []);
      setTransactions((transactionsResult.data || []).map(t => ({
        ...t,
        date: new Date(t.date),
        createdAt: new Date(t.created_at)
      })));
      setCategories(categoriesResult.data || []);
      setClients((clientsResult.data || []).map(c => ({
        ...c,
        createdAt: new Date(c.created_at)
      })));
      setBankAccounts((bankAccountsResult.data || []).map(b => ({
        ...b,
        createdAt: new Date(b.created_at)
      })));
      setClientOrders((clientOrdersResult.data || []).map(o => ({
        ...o,
        receivedDate: new Date(o.received_date),
        deliveredDate: o.delivered_date ? new Date(o.delivered_date) : undefined,
        archivedDate: o.archived_date ? new Date(o.archived_date) : undefined,
        createdAt: new Date(o.created_at)
      })));

    } catch (err) {
      console.error('Error loading data:', err);
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  // Save functions
  const saveUser = async (user: User) => {
    const { error } = await supabase
      .from('users')
      .upsert(user);
    if (error) throw error;
  };

  const saveTransaction = async (transaction: Transaction) => {
    const { error } = await supabase
      .from('transactions')
      .upsert({
        ...transaction,
        created_at: transaction.createdAt.toISOString()
      });
    if (error) throw error;
  };

  const saveCategory = async (category: Category) => {
    const { error } = await supabase
      .from('categories')
      .upsert(category);
    if (error) throw error;
  };

  const saveClient = async (client: Client) => {
    const { error } = await supabase
      .from('clients')
      .upsert({
        ...client,
        created_at: client.createdAt.toISOString()
      });
    if (error) throw error;
  };

  const saveBankAccount = async (bankAccount: BankAccount) => {
    const { error } = await supabase
      .from('bank_accounts')
      .upsert({
        ...bankAccount,
        created_at: bankAccount.createdAt.toISOString()
      });
    if (error) throw error;
  };

  const saveClientOrder = async (clientOrder: ClientOrder) => {
    const { error } = await supabase
      .from('client_orders')
      .upsert({
        ...clientOrder,
        received_date: clientOrder.receivedDate.toISOString(),
        delivered_date: clientOrder.deliveredDate?.toISOString(),
        archived_date: clientOrder.archivedDate?.toISOString(),
        created_at: clientOrder.createdAt.toISOString()
      });
    if (error) throw error;
  };

  // Delete functions
  const deleteTransaction = async (id: string) => {
    const { error } = await supabase
      .from('transactions')
      .delete()
      .eq('id', id);
    if (error) throw error;
  };

  const deleteUser = async (id: string) => {
    const { error } = await supabase
      .from('users')
      .delete()
      .eq('id', id);
    if (error) throw error;
  };

  const deleteCategory = async (id: string) => {
    const { error } = await supabase
      .from('categories')
      .delete()
      .eq('id', id);
    if (error) throw error;
  };

  const deleteClient = async (id: string) => {
    const { error } = await supabase
      .from('clients')
      .delete()
      .eq('id', id);
    if (error) throw error;
  };

  const deleteBankAccount = async (id: string) => {
    const { error } = await supabase
      .from('bank_accounts')
      .delete()
      .eq('id', id);
    if (error) throw error;
  };

  const deleteClientOrder = async (id: string) => {
    const { error } = await supabase
      .from('client_orders')
      .delete()
      .eq('id', id);
    if (error) throw error;
  };

  useEffect(() => {
    const checkAndLoadData = async () => {
      try {
        // Check if environment variables are available
        const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
        const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
        
        if (!supabaseUrl || !supabaseKey) {
          setError('Variables d\'environnement Supabase manquantes');
          setLoading(false);
          return;
        }
        
        await loadData();
      } catch (err) {
        console.error('Erreur lors du chargement des données Supabase:', err);
        setError(err instanceof Error ? err.message : 'Erreur inconnue');
        setLoading(false);
      }
    };

    checkAndLoadData();
  }, []);

  return {
    // Data
    users,
    transactions,
    categories,
    clients,
    bankAccounts,
    clientOrders,
    loading,
    error,
    
    // Actions
    loadData,
    saveUser,
    saveTransaction,
    saveCategory,
    saveClient,
    saveBankAccount,
    saveClientOrder,
    deleteTransaction,
    deleteUser,
    deleteCategory,
    deleteClient,
    deleteBankAccount,
    deleteClientOrder,
    
    // Setters for local updates
    setUsers,
    setTransactions,
    setCategories,
    setClients,
    setBankAccounts,
    setClientOrders
  };
};