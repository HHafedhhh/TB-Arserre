import React, { useState } from 'react';
import { Filter, Calendar, User, Tag, Search, Building2, Edit2, Trash2, Save, X, ChevronDown, ChevronUp, CreditCard, Banknote, ArrowUpDown } from 'lucide-react';
import { Transaction, User as UserType, Category, Client, BankAccount, FilterOptions } from '../types';

interface TransactionListProps {
  transactions: Transaction[];
  users: UserType[];
  categories: Category[];
  clients: Client[];
  bankAccounts: BankAccount[];
  onUpdateTransaction: (transaction: Transaction) => void;
  onDeleteTransaction: (transactionId: string) => void;
}

export const TransactionList: React.FC<TransactionListProps> = ({ 
  transactions, 
  users, 
  categories, 
  clients,
  bankAccounts,
  onUpdateTransaction,
  onDeleteTransaction
}) => {
  const [filters, setFilters] = useState<FilterOptions>({
    type: 'all',
    startDate: undefined,
    endDate: undefined,
    userId: '',
    category: '',
    clientId: '',
    bankAccountId: '',
    paymentMethod: 'all'
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [expandedTransaction, setExpandedTransaction] = useState<string | null>(null);

  const filteredTransactions = transactions.filter(transaction => {
    if (filters.type !== 'all' && transaction.type !== filters.type) return false;
    if (filters.userId && transaction.userId !== filters.userId) return false;
    if (filters.category && transaction.category !== filters.category) return false;
    if (filters.clientId && transaction.clientId !== filters.clientId) return false;
    if (filters.bankAccountId && transaction.bankAccountId !== filters.bankAccountId) return false;
    if (filters.paymentMethod !== 'all' && transaction.paymentMethod !== filters.paymentMethod) return false;
    if (filters.startDate && transaction.date < filters.startDate) return false;
    if (filters.endDate && transaction.date > filters.endDate) return false;
    if (searchTerm && !transaction.description.toLowerCase().includes(searchTerm.toLowerCase())) return false;
    return true;
  });

  const getUserName = (userId: string) => {
    const user = users.find(u => u.id === userId);
    return user ? user.name : 'Utilisateur inconnu';
  };

  const getClientName = (clientId: string) => {
    const client = clients.find(c => c.id === clientId);
    return client ? client.name : 'Client inconnu';
  };

  const getBankAccountName = (bankAccountId: string) => {
    const account = bankAccounts.find(a => a.id === bankAccountId);
    return account ? `${account.name} - ${account.bankName}` : 'Compte inconnu';
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'income': return '+';
      case 'expense': return '-';
      case 'transfer': return '↔';
      case 'bank_transfer': return '⇅';
      default: return '?';
    }
  };

  const getTransactionColor = (type: string) => {
    switch (type) {
      case 'income': return 'text-green-600 bg-green-50 border-green-200';
      case 'expense': return 'text-red-600 bg-red-50 border-red-200';
      case 'transfer': return 'text-purple-600 bg-purple-50 border-purple-200';
      case 'bank_transfer': return 'text-blue-600 bg-blue-50 border-blue-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'income': return 'Entrée';
      case 'expense': return 'Sortie';
      case 'transfer': return 'Transfert';
      case 'bank_transfer': return 'Banque';
      default: return type;
    }
  };

  const getPaymentMethodIcon = (method: string) => {
    switch (method) {
      case 'cash': return <Banknote className="w-4 h-4" />;
      case 'bank': return <CreditCard className="w-4 h-4" />;
      case 'transfer': return <ArrowUpDown className="w-4 h-4" />;
      default: return <Banknote className="w-4 h-4" />;
    }
  };

  const getPaymentMethodLabel = (method: string) => {
    switch (method) {
      case 'cash': return 'Espèces';
      case 'bank': return 'Bancaire';
      case 'transfer': return 'Transfert';
      default: return method;
    }
  };

  const handleEditTransaction = (transaction: Transaction) => {
    setEditingTransaction({ ...transaction });
    setExpandedTransaction(null);
  };

  const handleSaveTransaction = () => {
    if (editingTransaction) {
      onUpdateTransaction(editingTransaction);
      setEditingTransaction(null);
    }
  };

  const handleDeleteTransaction = (transactionId: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cette transaction ?')) {
      onDeleteTransaction(transactionId);
    }
  };

  const getAvailableCategories = (type: string) => {
    if (type === 'transfer') return [];
    if (type === 'bank_transfer') {
      return categories.filter(cat => cat.name === 'Transfert Bancaire');
    }
    
    return categories.filter(cat => {
      if (type === 'income') {
        return cat.type === 'income' && cat.parentCategory && cat.name !== 'Transfert Bancaire';
      } else {
        return cat.type === 'expense' && cat.parentCategory;
      }
    });
  };

  const selectedCategory = editingTransaction ? categories.find(cat => cat.name === editingTransaction.category) : null;
  const activeBankAccounts = bankAccounts.filter(account => account.isActive);

  const years = Array.from(new Set(transactions.map(t => new Date(t.date).getFullYear()))).sort((a, b) => b - a);

  const toggleTransactionDetails = (transactionId: string) => {
    setExpandedTransaction(expandedTransaction === transactionId ? null : transactionId);
  };

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      {/* Header */}
      <div className="p-4 sm:p-6 border-b border-gray-200">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <h2 className="text-xl font-semibold text-gray-800 flex items-center">
            <Filter className="w-5 h-5 mr-2" />
            Transactions
          </h2>
          <div className="flex items-center justify-between sm:justify-end gap-4">
            <div className="text-sm text-gray-500">
              {filteredTransactions.length} transaction(s)
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="sm:hidden bg-blue-500 text-white px-3 py-2 rounded-lg text-sm flex items-center"
            >
              <Filter className="w-4 h-4 mr-1" />
              Filtres
              {showFilters ? <ChevronUp className="w-4 h-4 ml-1" /> : <ChevronDown className="w-4 h-4 ml-1" />}
            </button>
          </div>
        </div>
      </div>

      {/* Search Bar - Always visible */}
      <div className="p-4 sm:p-6 border-b border-gray-200">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Rechercher dans les descriptions..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base"
          />
        </div>
      </div>

      {/* Filters */}
      <div className={`border-b border-gray-200 transition-all duration-300 ${showFilters || window.innerWidth >= 640 ? 'block' : 'hidden'}`}>
        <div className="p-4 sm:p-6 space-y-4">
          {/* Quick Filter Buttons */}
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setFilters(prev => ({ ...prev, type: 'all' }))}
              className={`px-3 py-2 rounded-full text-sm font-medium transition-colors ${
                filters.type === 'all' 
                  ? 'bg-blue-500 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Tous
            </button>
            <button
              onClick={() => setFilters(prev => ({ ...prev, type: 'income' }))}
              className={`px-3 py-2 rounded-full text-sm font-medium transition-colors ${
                filters.type === 'income' 
                  ? 'bg-green-500 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Entrées
            </button>
            <button
              onClick={() => setFilters(prev => ({ ...prev, type: 'expense' }))}
              className={`px-3 py-2 rounded-full text-sm font-medium transition-colors ${
                filters.type === 'expense' 
                  ? 'bg-red-500 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Sorties
            </button>
            <button
              onClick={() => setFilters(prev => ({ ...prev, type: 'transfer' }))}
              className={`px-3 py-2 rounded-full text-sm font-medium transition-colors ${
                filters.type === 'transfer' 
                  ? 'bg-purple-500 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Transferts
            </button>
            <button
              onClick={() => setFilters(prev => ({ ...prev, type: 'bank_transfer' }))}
              className={`px-3 py-2 rounded-full text-sm font-medium transition-colors ${
                filters.type === 'bank_transfer' 
                  ? 'bg-blue-500 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Banque
            </button>
          </div>

          {/* Payment Method Filters */}
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setFilters(prev => ({ ...prev, paymentMethod: 'all' }))}
              className={`px-3 py-2 rounded-full text-sm font-medium transition-colors flex items-center ${
                filters.paymentMethod === 'all' 
                  ? 'bg-gray-500 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Tous les modes
            </button>
            <button
              onClick={() => setFilters(prev => ({ ...prev, paymentMethod: 'cash' }))}
              className={`px-3 py-2 rounded-full text-sm font-medium transition-colors flex items-center ${
                filters.paymentMethod === 'cash' 
                  ? 'bg-green-500 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <Banknote className="w-4 h-4 mr-1" />
              Espèces
            </button>
            <button
              onClick={() => setFilters(prev => ({ ...prev, paymentMethod: 'bank' }))}
              className={`px-3 py-2 rounded-full text-sm font-medium transition-colors flex items-center ${
                filters.paymentMethod === 'bank' 
                  ? 'bg-blue-500 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <CreditCard className="w-4 h-4 mr-1" />
              Bancaire
            </button>
            <button
              onClick={() => setFilters(prev => ({ ...prev, paymentMethod: 'transfer' }))}
              className={`px-3 py-2 rounded-full text-sm font-medium transition-colors flex items-center ${
                filters.paymentMethod === 'transfer' 
                  ? 'bg-purple-500 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <ArrowUpDown className="w-4 h-4 mr-1" />
              Transfert
            </button>
          </div>

          {/* Advanced Filters */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <select
              value={filters.userId}
              onChange={(e) => setFilters(prev => ({ ...prev, userId: e.target.value }))}
              className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base"
            >
              <option value="">Tous les utilisateurs</option>
              {users.map(user => (
                <option key={user.id} value={user.id}>{user.name}</option>
              ))}
            </select>

            <select
              value={filters.category}
              onChange={(e) => setFilters(prev => ({ ...prev, category: e.target.value }))}
              className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base"
            >
              <option value="">Toutes les catégories</option>
              {categories.filter(cat => cat.parentCategory).map(category => (
                <option key={category.id} value={category.name}>{category.name}</option>
              ))}
            </select>

            <select
              value={filters.clientId}
              onChange={(e) => setFilters(prev => ({ ...prev, clientId: e.target.value }))}
              className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base"
            >
              <option value="">Tous les clients</option>
              {clients.map(client => (
                <option key={client.id} value={client.id}>{client.name}</option>
              ))}
            </select>

            <select
              value={filters.bankAccountId}
              onChange={(e) => setFilters(prev => ({ ...prev, bankAccountId: e.target.value }))}
              className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base"
            >
              <option value="">Tous les comptes</option>
              {bankAccounts.map(account => (
                <option key={account.id} value={account.id}>{account.name} - {account.bankName}</option>
              ))}
            </select>
          </div>

          {/* Date Filters */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Date de début</label>
              <input
                type="date"
                value={filters.startDate ? filters.startDate.toISOString().split('T')[0] : ''}
                onChange={(e) => setFilters(prev => ({ 
                  ...prev, 
                  startDate: e.target.value ? new Date(e.target.value) : undefined 
                }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Date de fin</label>
              <input
                type="date"
                value={filters.endDate ? filters.endDate.toISOString().split('T')[0] : ''}
                onChange={(e) => setFilters(prev => ({ 
                  ...prev, 
                  endDate: e.target.value ? new Date(e.target.value) : undefined 
                }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Année</label>
              <select
                value={filters.year || ''}
                onChange={(e) => setFilters(prev => ({ ...prev, year: e.target.value ? parseInt(e.target.value) : undefined }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base"
              >
                <option value="">Toutes les années</option>
                {years.map(year => (
                  <option key={year} value={year}>{year}</option>
                ))}
              </select>
            </div>
          </div>

          <button
            onClick={() => setFilters({ type: 'all', userId: '', category: '', clientId: '', bankAccountId: '', paymentMethod: 'all' })}
            className="w-full sm:w-auto px-6 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors font-medium"
          >
            Réinitialiser les filtres
          </button>
        </div>
      </div>

      {/* Transaction List */}
      <div className="max-h-[60vh] overflow-y-auto">
        {filteredTransactions.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <Filter className="w-12 h-12 mx-auto mb-4 text-gray-300" />
            <p className="text-lg font-medium mb-2">Aucune transaction trouvée</p>
            <p className="text-sm">Essayez de modifier vos filtres de recherche</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {filteredTransactions.map((transaction) => (
              <div key={transaction.id} className="hover:bg-gray-50 transition-colors">
                {editingTransaction?.id === transaction.id ? (
                  // Edit Mode
                  <div className="p-4 sm:p-6 bg-blue-50 border-l-4 border-blue-500">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold text-gray-800">Modifier la transaction</h3>
                        <div className={`px-3 py-1 rounded-full text-sm font-medium ${getTransactionColor(editingTransaction.type)}`}>
                          {getTypeLabel(editingTransaction.type)}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Montant (TND)</label>
                          <input
                            type="number"
                            step="0.01"
                            value={editingTransaction.amount}
                            onChange={(e) => setEditingTransaction(prev => prev ? { ...prev, amount: parseFloat(e.target.value) || 0 } : null)}
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Date</label>
                          <input
                            type="date"
                            value={editingTransaction.date.toISOString().split('T')[0]}
                            onChange={(e) => setEditingTransaction(prev => prev ? { ...prev, date: new Date(e.target.value) } : null)}
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                        <input
                          type="text"
                          value={editingTransaction.description}
                          onChange={(e) => setEditingTransaction(prev => prev ? { ...prev, description: e.target.value } : null)}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base"
                        />
                      </div>

                      {/* Payment Method for income/expense */}
                      {(editingTransaction.type === 'income' || editingTransaction.type === 'expense') && (
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Mode de paiement</label>
                          <select
                            value={editingTransaction.paymentMethod}
                            onChange={(e) => setEditingTransaction(prev => prev ? { ...prev, paymentMethod: e.target.value as any } : null)}
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base"
                          >
                            <option value="cash">Espèces</option>
                            <option value="bank">Bancaire</option>
                          </select>
                        </div>
                      )}

                      {editingTransaction.type !== 'transfer' && editingTransaction.type !== 'bank_transfer' && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Catégorie</label>
                            <select
                              value={editingTransaction.category}
                              onChange={(e) => setEditingTransaction(prev => prev ? { ...prev, category: e.target.value, subcategory: '' } : null)}
                              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base"
                            >
                              <option value="">Sélectionner une catégorie</option>
                              {getAvailableCategories(editingTransaction.type).map(category => (
                                <option key={category.id} value={category.name}>{category.name}</option>
                              ))}
                            </select>
                          </div>

                          {selectedCategory?.subcategories && (
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Sous-catégorie</label>
                              <select
                                value={editingTransaction.subcategory || ''}
                                onChange={(e) => setEditingTransaction(prev => prev ? { ...prev, subcategory: e.target.value } : null)}
                                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base"
                              >
                                <option value="">Sélectionner une sous-catégorie</option>
                                {selectedCategory.subcategories.map(sub => (
                                  <option key={sub} value={sub}>{sub}</option>
                                ))}
                              </select>
                            </div>
                          )}
                        </div>
                      )}

                      {editingTransaction.type === 'income' && editingTransaction.category === 'Recouvrement Client' && (
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">Client</label>
                          <select
                            value={editingTransaction.clientId || ''}
                            onChange={(e) => setEditingTransaction(prev => prev ? { ...prev, clientId: e.target.value || undefined } : null)}
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base"
                          >
                            <option value="">Sélectionner un client</option>
                            {clients.map(client => (
                              <option key={client.id} value={client.id}>{client.name}</option>
                            ))}
                          </select>
                        </div>
                      )}

                      {(editingTransaction.paymentMethod === 'bank' || editingTransaction.type === 'bank_transfer') && (
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            <CreditCard className="w-4 h-4 inline mr-1" />
                            Compte bancaire
                          </label>
                          <select
                            value={editingTransaction.bankAccountId || ''}
                            onChange={(e) => setEditingTransaction(prev => prev ? { ...prev, bankAccountId: e.target.value || undefined } : null)}
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base"
                          >
                            <option value="">Sélectionner un compte</option>
                            {activeBankAccounts.map(account => (
                              <option key={account.id} value={account.id}>
                                {account.name} - {account.bankName} ({account.currency})
                              </option>
                            ))}
                          </select>
                        </div>
                      )}

                      <div className="flex flex-col sm:flex-row gap-3 pt-4">
                        <button
                          onClick={handleSaveTransaction}
                          className="flex-1 bg-green-500 text-white px-6 py-3 rounded-lg hover:bg-green-600 transition-colors flex items-center justify-center font-medium"
                        >
                          <Save className="w-5 h-5 mr-2" />
                          Sauvegarder
                        </button>
                        <button
                          onClick={() => setEditingTransaction(null)}
                          className="flex-1 bg-gray-500 text-white px-6 py-3 rounded-lg hover:bg-gray-600 transition-colors flex items-center justify-center font-medium"
                        >
                          <X className="w-5 h-5 mr-2" />
                          Annuler
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  // View Mode
                  <div className="p-4 sm:p-6">
                    {/* Main Transaction Info */}
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-4 flex-1 min-w-0">
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg flex-shrink-0 border-2 ${getTransactionColor(transaction.type)}`}>
                          {getTransactionIcon(transaction.type)}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-2">
                            <h3 className="font-semibold text-gray-800 text-lg truncate">{transaction.description}</h3>
                            <div className="flex items-center space-x-3 flex-shrink-0">
                              <p className={`text-xl font-bold ${
                                transaction.type === 'income' ? 'text-green-600' : 
                                transaction.type === 'expense' ? 'text-red-600' : 
                                transaction.type === 'bank_transfer' ? 'text-blue-600' : 'text-purple-600'
                              }`}>
                                {transaction.type === 'income' ? '+' : 
                                 transaction.type === 'expense' ? '-' : 
                                 transaction.type === 'bank_transfer' ? '⇅' : ''}
                                {transaction.amount.toFixed(2)} TND
                              </p>
                            </div>
                          </div>

                          {/* Quick Info */}
                          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-gray-600 mb-3">
                            <span className="flex items-center">
                              <Calendar className="w-4 h-4 mr-1 flex-shrink-0" />
                              {new Date(transaction.date).toLocaleDateString('fr-FR')}
                            </span>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getTransactionColor(transaction.type)}`}>
                              {getTypeLabel(transaction.type)}
                            </span>
                            <span className="flex items-center px-2 py-1 bg-gray-100 rounded-full text-xs font-medium">
                              {getPaymentMethodIcon(transaction.paymentMethod)}
                              <span className="ml-1">{getPaymentMethodLabel(transaction.paymentMethod)}</span>
                            </span>
                          </div>

                          {/* Expandable Details */}
                          {expandedTransaction === transaction.id && (
                            <div className="mt-4 p-4 bg-gray-50 rounded-lg space-y-3">
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                                <div>
                                  <span className="font-medium text-gray-700">Utilisateur:</span>
                                  <p className="text-gray-600 flex items-center mt-1">
                                    <User className="w-4 h-4 mr-1" />
                                    {getUserName(transaction.userId)}
                                  </p>
                                </div>
                                <div>
                                  <span className="font-medium text-gray-700">Catégorie:</span>
                                  <p className="text-gray-600 flex items-center mt-1">
                                    <Tag className="w-4 h-4 mr-1" />
                                    {transaction.category}
                                    {transaction.subcategory && ` - ${transaction.subcategory}`}
                                  </p>
                                </div>
                                {transaction.clientId && (
                                  <div>
                                    <span className="font-medium text-gray-700">Client:</span>
                                    <p className="text-gray-600 flex items-center mt-1">
                                      <Building2 className="w-4 h-4 mr-1" />
                                      {getClientName(transaction.clientId)}
                                    </p>
                                  </div>
                                )}
                                {transaction.bankAccountId && (
                                  <div>
                                    <span className="font-medium text-gray-700">Compte bancaire:</span>
                                    <p className="text-gray-600 flex items-center mt-1">
                                      <CreditCard className="w-4 h-4 mr-1" />
                                      {getBankAccountName(transaction.bankAccountId)}
                                    </p>
                                  </div>
                                )}
                                {transaction.type === 'transfer' && (
                                  <div>
                                    <span className="font-medium text-gray-700">Transfert:</span>
                                    <p className="text-purple-600 mt-1">
                                      De {getUserName(transaction.fromUser!)} vers {getUserName(transaction.toUser!)}
                                    </p>
                                  </div>
                                )}
                              </div>
                            </div>
                          )}

                          {/* Action Buttons */}
                          <div className="flex items-center justify-between mt-4">
                            <button
                              onClick={() => toggleTransactionDetails(transaction.id)}
                              className="text-blue-600 hover:text-blue-800 text-sm font-medium flex items-center"
                            >
                              {expandedTransaction === transaction.id ? (
                                <>
                                  <ChevronUp className="w-4 h-4 mr-1" />
                                  Moins de détails
                                </>
                              ) : (
                                <>
                                  <ChevronDown className="w-4 h-4 mr-1" />
                                  Plus de détails
                                </>
                              )}
                            </button>
                            <div className="flex items-center space-x-3">
                              <button
                                onClick={() => handleEditTransaction(transaction)}
                                className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors flex items-center text-sm font-medium"
                              >
                                <Edit2 className="w-4 h-4 mr-1" />
                                Modifier
                              </button>
                              <button
                                onClick={() => handleDeleteTransaction(transaction.id)}
                                className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors flex items-center text-sm font-medium"
                              >
                                <Trash2 className="w-4 h-4 mr-1" />
                                Supprimer
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};