import React from 'react';
import { Database, Wifi, WifiOff, AlertCircle, CheckCircle } from 'lucide-react';

interface DatabaseStatusProps {
  isConnected: boolean;
  loading: boolean;
  error: string | null;
}

export const DatabaseStatus: React.FC<DatabaseStatusProps> = ({ isConnected, loading, error }) => {
  if (loading) {
    return (
      <div className="fixed top-4 right-4 bg-blue-100 border border-blue-300 rounded-lg p-3 flex items-center space-x-2 z-50">
        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
        <span className="text-blue-800 text-sm font-medium">Connexion à la base de données...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="fixed top-4 right-4 bg-red-100 border border-red-300 rounded-lg p-3 flex items-center space-x-2 z-50">
        <AlertCircle className="w-4 h-4 text-red-600" />
        <span className="text-red-800 text-sm font-medium">Erreur DB: {error}</span>
      </div>
    );
  }

  if (isConnected) {
    return (
      <div className="fixed top-4 right-4 bg-green-100 border border-green-300 rounded-lg p-3 flex items-center space-x-2 z-50">
        <CheckCircle className="w-4 h-4 text-green-600" />
        <Database className="w-4 h-4 text-green-600" />
        <span className="text-green-800 text-sm font-medium">Base de données connectée</span>
      </div>
    );
  }

  return (
    <div className="fixed top-4 right-4 bg-yellow-100 border border-yellow-300 rounded-lg p-3 flex items-center space-x-2 z-50">
      <WifiOff className="w-4 h-4 text-yellow-600" />
      <span className="text-yellow-800 text-sm font-medium">Mode hors ligne (localStorage)</span>
    </div>
  );
};