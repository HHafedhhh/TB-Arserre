import React, { useState } from 'react';
import { Plus, ArrowLeftRight, Minus, CreditCard, Banknote, ArrowUpDown } from 'lucide-react';
import { Transaction, User, Category, Client, BankAccount, ClientOrder } from '../types';

interface TransactionFormProps {
  users: User[];
  categories: Category[];
  clients: Client[];
  bankAccounts: BankAccount[];
  onAddTransaction: (transaction: Omit<Transaction, 'id' | 'createdAt'>) => void;
}

export const TransactionForm: React.FC<TransactionFormProps> = ({ users, categories, clients, bankAccounts, onAddTransaction }) => {
  const [formData, setFormData] = useState({
    type: 'income' as 'income' | 'expense' | 'transfer' | 'bank_transfer',
    amount: '',
    description: '',
    category: '',
    subcategory: '',
    fromUser: '',
    toUser: '',
    userId: '',
    clientId: '',
    bankAccountId: '',
    orderId: '',
    paymentMethod: 'cash' as 'cash' | 'bank' | 'transfer',
    date: new Date().toISOString().split('T')[0]
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.amount || !formData.description || !formData.userId) return;

    const transaction: Omit<Transaction, 'id' | 'createdAt'> = {
      type: formData.type,
      amount: parseFloat(formData.amount),
      description: formData.description,
      category: formData.category,
      subcategory: formData.subcategory || undefined,
      fromUser: formData.type === 'transfer' ? formData.fromUser : undefined,
      toUser: formData.type === 'transfer' ? formData.toUser : undefined,
      userId: formData.userId,
      clientId: formData.clientId || undefined,
      bankAccountId: formData.bankAccountId || undefined,
      orderId: formData.orderId || undefined,
      paymentMethod: formData.paymentMethod,
      date: new Date(formData.date)
    };

    onAddTransaction(transaction);
    setFormData({
      type: 'income',
      amount: '',
      description: '',
      category: '',
      subcategory: '',
      fromUser: '',
      toUser: '',
      userId: '',
      clientId: '',
      bankAccountId: '',
      orderId: '',
      paymentMethod: 'cash',
      date: new Date().toISOString().split('T')[0]
    });
  };

  const getAvailableCategories = () => {
    if (formData.type === 'transfer') return [];
    if (formData.type === 'bank_transfer') {
      return categories.filter(cat => cat.name === 'Transfert Bancaire');
    }
    
    return categories.filter(cat => {
      if (formData.type === 'income') {
        return cat.type === 'income' && cat.parentCategory && cat.name !== 'Transfert Bancaire';
      } else {
        return cat.type === 'expense' && cat.parentCategory;
      }
    });
  };

  const selectedCategory = categories.find(cat => cat.name === formData.category);
  const activeBankAccounts = bankAccounts.filter(account => account.isActive);

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-6 flex items-center">
        <Plus className="w-5 h-5 mr-2" />
        Nouvelle Transaction
      </h2>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <button
            type="button"
            onClick={() => setFormData(prev => ({ ...prev, type: 'income', category: '', subcategory: '', paymentMethod: 'cash' }))}
            className={`p-4 rounded-lg border-2 transition-all ${
              formData.type === 'income' 
                ? 'border-green-500 bg-green-50 text-green-700' 
                : 'border-gray-200 hover:border-green-300'
            }`}
          >
            <Plus className="w-6 h-6 mx-auto mb-2" />
            <span className="font-medium">Entrée Argent</span>
          </button>
          <button
            type="button"
            onClick={() => setFormData(prev => ({ ...prev, type: 'expense', category: '', subcategory: '', paymentMethod: 'cash' }))}
            className={`p-4 rounded-lg border-2 transition-all ${
              formData.type === 'expense' 
                ? 'border-red-500 bg-red-50 text-red-700' 
                : 'border-gray-200 hover:border-red-300'
            }`}
          >
            <Minus className="w-6 h-6 mx-auto mb-2" />
            <span className="font-medium">Sortie Argent</span>
          </button>
          <button
            type="button"
            onClick={() => setFormData(prev => ({ ...prev, type: 'transfer', category: 'Transfert entre user', subcategory: 'Transfert interne', paymentMethod: 'transfer' }))}
            className={`p-4 rounded-lg border-2 transition-all ${
              formData.type === 'transfer' 
                ? 'border-purple-500 bg-purple-50 text-purple-700' 
                : 'border-gray-200 hover:border-purple-300'
            }`}
          >
            <ArrowLeftRight className="w-6 h-6 mx-auto mb-2" />
            <span className="font-medium">Transfert</span>
          </button>
          <button
            type="button"
            onClick={() => setFormData(prev => ({ ...prev, type: 'bank_transfer', category: 'Transfert Bancaire', subcategory: '', paymentMethod: 'transfer' }))}
            className={`p-4 rounded-lg border-2 transition-all ${
              formData.type === 'bank_transfer' 
                ? 'border-blue-500 bg-blue-50 text-blue-700' 
                : 'border-gray-200 hover:border-blue-300'
            }`}
          >
            <ArrowUpDown className="w-6 h-6 mx-auto mb-2" />
            <span className="font-medium">Banque</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Montant (TND)
            </label>
            <input
              type="number"
              step="0.01"
              min="0"
              value={formData.amount}
              onChange={(e) => setFormData(prev => ({ ...prev, amount: e.target.value }))}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="0.00"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Date
            </label>
            <input
              type="date"
              value={formData.date}
              onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Description
          </label>
          <input
            type="text"
            value={formData.description}
            onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Description de la transaction"
            required
          />
        </div>

        {/* Payment Method Selection */}
        {(formData.type === 'income' || formData.type === 'expense') && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Mode de paiement
            </label>
            <div className="grid grid-cols-2 gap-4">
              <button
                type="button"
                onClick={() => setFormData(prev => ({ ...prev, paymentMethod: 'cash', bankAccountId: '' }))}
                className={`p-3 rounded-lg border-2 transition-all flex items-center justify-center ${
                  formData.paymentMethod === 'cash' 
                    ? 'border-green-500 bg-green-50 text-green-700' 
                    : 'border-gray-200 hover:border-green-300'
                }`}
              >
                <Banknote className="w-5 h-5 mr-2" />
                Espèces
              </button>
              <button
                type="button"
                onClick={() => setFormData(prev => ({ ...prev, paymentMethod: 'bank' }))}
                className={`p-3 rounded-lg border-2 transition-all flex items-center justify-center ${
                  formData.paymentMethod === 'bank' 
                    ? 'border-blue-500 bg-blue-50 text-blue-700' 
                    : 'border-gray-200 hover:border-blue-300'
                }`}
              >
                <CreditCard className="w-5 h-5 mr-2" />
                Bancaire
              </button>
            </div>
          </div>
        )}

        {formData.type === 'transfer' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                De (Utilisateur)
              </label>
              <select
                value={formData.fromUser}
                onChange={(e) => setFormData(prev => ({ ...prev, fromUser: e.target.value, userId: e.target.value }))}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                <option value="">Sélectionner un utilisateur</option>
                {users.map(user => (
                  <option key={user.id} value={user.id}>{user.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Vers (Utilisateur)
              </label>
              <select
                value={formData.toUser}
                onChange={(e) => setFormData(prev => ({ ...prev, toUser: e.target.value }))}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                <option value="">Sélectionner un utilisateur</option>
                {users.filter(user => user.id !== formData.fromUser).map(user => (
                  <option key={user.id} value={user.id}>{user.name}</option>
                ))}
              </select>
            </div>
          </div>
        ) : formData.type === 'bank_transfer' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Utilisateur
              </label>
              <select
                value={formData.userId}
                onChange={(e) => setFormData(prev => ({ ...prev, userId: e.target.value }))}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                <option value="">Sélectionner un utilisateur</option>
                {users.map(user => (
                  <option key={user.id} value={user.id}>{user.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Compte bancaire
              </label>
              <select
                value={formData.bankAccountId}
                onChange={(e) => setFormData(prev => ({ ...prev, bankAccountId: e.target.value }))}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                <option value="">Sélectionner un compte</option>
                {activeBankAccounts.map(account => (
                  <option key={account.id} value={account.id}>
                    {account.name} - {account.bankName} ({account.currency})
                  </option>
                ))}
              </select>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Utilisateur
              </label>
              <select
                value={formData.userId}
                onChange={(e) => setFormData(prev => ({ ...prev, userId: e.target.value }))}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                <option value="">Sélectionner un utilisateur</option>
                {users.map(user => (
                  <option key={user.id} value={user.id}>{user.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Catégorie
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value, subcategory: '' }))}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required={formData.type !== 'transfer'}
              >
                <option value="">Sélectionner une catégorie</option>
                {getAvailableCategories().map(category => (
                  <option key={category.id} value={category.name}>{category.name}</option>
                ))}
              </select>
            </div>
          </div>
        )}

        {selectedCategory?.subcategories && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Sous-catégorie
            </label>
            <select
              value={formData.subcategory}
              onChange={(e) => setFormData(prev => ({ ...prev, subcategory: e.target.value }))}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Sélectionner une sous-catégorie</option>
              {selectedCategory.subcategories.map(sub => (
                <option key={sub} value={sub}>{sub}</option>
              ))}
            </select>
          </div>
        )}

        {formData.type === 'income' && formData.category === 'Recouvrement Client' && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Client
            </label>
            <select
              value={formData.clientId}
              onChange={(e) => setFormData(prev => ({ ...prev, clientId: e.target.value }))}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Sélectionner un client (optionnel)</option>
              {clients.map(client => (
                <option key={client.id} value={client.id}>{client.name}</option>
              ))}
            </select>
          </div>
        )}

        {formData.paymentMethod === 'bank' && formData.type !== 'bank_transfer' && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <CreditCard className="w-4 h-4 inline mr-1" />
              Compte bancaire
            </label>
            <select
              value={formData.bankAccountId}
              onChange={(e) => setFormData(prev => ({ ...prev, bankAccountId: e.target.value }))}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required={formData.paymentMethod === 'bank'}
            >
              <option value="">Sélectionner un compte</option>
              {activeBankAccounts.map(account => (
                <option key={account.id} value={account.id}>
                  {account.name} - {account.bankName} ({account.currency})
                </option>
              ))}
            </select>
          </div>
        )}

        <button
          type="submit"
          className="w-full bg-gradient-to-r from-blue-500 to-blue-600 text-white py-3 px-6 rounded-lg hover:from-blue-600 hover:to-blue-700 transition-all duration-200 font-medium shadow-lg hover:shadow-xl"
        >
          Ajouter la Transaction
        </button>
      </form>
    </div>
  );
};