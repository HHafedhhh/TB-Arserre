import React, { useState } from 'react';
import { Settings as SettingsIcon, Users, Tag, Plus, Edit2, Trash2, Save, X, Building2, CreditCard } from 'lucide-react';
import { User, Category, Client, BankAccount } from '../types';

interface SettingsProps {
  users: User[];
  categories: Category[];
  clients: Client[];
  bankAccounts: BankAccount[];
  onUpdateUsers: (users: User[]) => void;
  onUpdateCategories: (categories: Category[]) => void;
  onUpdateClients: (clients: Client[]) => void;
  onUpdateBankAccounts: (bankAccounts: BankAccount[]) => void;
}

export const Settings: React.FC<SettingsProps> = ({ 
  users, 
  categories, 
  clients,
  bankAccounts,
  onUpdateUsers, 
  onUpdateCategories,
  onUpdateClients,
  onUpdateBankAccounts
}) => {
  const [activeTab, setActiveTab] = useState<'users' | 'categories' | 'clients' | 'bankAccounts' | 'general'>('categories');
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [editingBankAccount, setEditingBankAccount] = useState<BankAccount | null>(null);
  const [newUser, setNewUser] = useState({ name: '', role: 'user' as 'admin' | 'user', balance: 0 });
  const [newCategory, setNewCategory] = useState({ 
    name: '', 
    type: 'expense' as 'income' | 'expense', 
    color: '#EF4444',
    subcategories: [] as string[],
    parentCategory: ''
  });
  const [newClient, setNewClient] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    balance: 0
  });
  const [newBankAccount, setNewBankAccount] = useState({
    name: '',
    accountNumber: '',
    bankName: '',
    balance: 0,
    currency: 'TND',
    isActive: true
  });
  const [newSubcategory, setNewSubcategory] = useState('');

  const handleAddUser = () => {
    if (!newUser.name.trim()) return;
    
    const user: User = {
      id: Date.now().toString(),
      name: newUser.name.trim(),
      role: newUser.role,
      balance: newUser.balance
    };
    
    onUpdateUsers([...users, user]);
    setNewUser({ name: '', role: 'user', balance: 0 });
  };

  const handleUpdateUser = (updatedUser: User) => {
    onUpdateUsers(users.map(user => user.id === updatedUser.id ? updatedUser : user));
    setEditingUser(null);
  };

  const handleDeleteUser = (userId: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur ?')) {
      onUpdateUsers(users.filter(user => user.id !== userId));
    }
  };

  const handleAddCategory = () => {
    if (!newCategory.name.trim()) return;
    
    const category: Category = {
      id: Date.now().toString(),
      name: newCategory.name.trim(),
      type: newCategory.type,
      color: newCategory.color,
      subcategories: newCategory.subcategories.length > 0 ? newCategory.subcategories : undefined,
      parentCategory: newCategory.parentCategory || undefined
    };
    
    onUpdateCategories([...categories, category]);
    setNewCategory({ name: '', type: 'expense', color: '#EF4444', subcategories: [], parentCategory: '' });
  };

  const handleUpdateCategory = (updatedCategory: Category) => {
    onUpdateCategories(categories.map(cat => cat.id === updatedCategory.id ? updatedCategory : cat));
    setEditingCategory(null);
  };

  const handleDeleteCategory = (categoryId: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cette catégorie ?')) {
      onUpdateCategories(categories.filter(cat => cat.id !== categoryId));
    }
  };

  const handleAddClient = () => {
    if (!newClient.name.trim()) return;
    
    const client: Client = {
      id: Date.now().toString(),
      name: newClient.name.trim(),
      email: newClient.email.trim() || undefined,
      phone: newClient.phone.trim() || undefined,
      address: newClient.address.trim() || undefined,
      balance: newClient.balance,
      createdAt: new Date()
    };
    
    onUpdateClients([...clients, client]);
    setNewClient({ name: '', email: '', phone: '', address: '', balance: 0 });
  };

  const handleUpdateClient = (updatedClient: Client) => {
    onUpdateClients(clients.map(client => client.id === updatedClient.id ? updatedClient : client));
    setEditingClient(null);
  };

  const handleDeleteClient = (clientId: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce client ?')) {
      onUpdateClients(clients.filter(client => client.id !== clientId));
    }
  };

  const handleAddBankAccount = () => {
    if (!newBankAccount.name.trim() || !newBankAccount.bankName.trim()) return;
    
    const bankAccount: BankAccount = {
      id: Date.now().toString(),
      name: newBankAccount.name.trim(),
      accountNumber: newBankAccount.accountNumber.trim(),
      bankName: newBankAccount.bankName.trim(),
      balance: newBankAccount.balance,
      currency: newBankAccount.currency,
      isActive: newBankAccount.isActive,
      createdAt: new Date()
    };
    
    onUpdateBankAccounts([...bankAccounts, bankAccount]);
    setNewBankAccount({ name: '', accountNumber: '', bankName: '', balance: 0, currency: 'TND', isActive: true });
  };

  const handleUpdateBankAccount = (updatedBankAccount: BankAccount) => {
    onUpdateBankAccounts(bankAccounts.map(account => account.id === updatedBankAccount.id ? updatedBankAccount : account));
    setEditingBankAccount(null);
  };

  const handleDeleteBankAccount = (bankAccountId: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce compte bancaire ?')) {
      onUpdateBankAccounts(bankAccounts.filter(account => account.id !== bankAccountId));
    }
  };

  const addSubcategoryToNew = () => {
    if (newSubcategory.trim() && !newCategory.subcategories.includes(newSubcategory.trim())) {
      setNewCategory(prev => ({
        ...prev,
        subcategories: [...prev.subcategories, newSubcategory.trim()]
      }));
      setNewSubcategory('');
    }
  };

  const removeSubcategoryFromNew = (subcategory: string) => {
    setNewCategory(prev => ({
      ...prev,
      subcategories: prev.subcategories.filter(sub => sub !== subcategory)
    }));
  };

  const getParentCategories = () => {
    return categories.filter(cat => !cat.parentCategory);
  };

  const getCategoriesByType = (type: 'income' | 'expense') => {
    return categories.filter(cat => cat.type === type && cat.parentCategory);
  };

  const handleExportData = () => {
    const data = {
      users,
      categories,
      clients,
      bankAccounts,
      exportDate: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cashflow-data-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImportData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target?.result as string);
        if (data.users) onUpdateUsers(data.users);
        if (data.categories) onUpdateCategories(data.categories);
        if (data.clients) onUpdateClients(data.clients);
        if (data.bankAccounts) onUpdateBankAccounts(data.bankAccounts);
        alert('Données importées avec succès !');
      } catch (error) {
        alert('Erreur lors de l\'importation des données');
      }
    };
    reader.readAsText(file);
  };

  const handleResetData = () => {
    if (confirm('Êtes-vous sûr de vouloir réinitialiser toutes les données ? Cette action est irréversible.')) {
      // Réinitialiser avec les données par défaut au lieu de vider
      const { users: defaultUsers, categories: defaultCategories, clients: defaultClients, bankAccounts: defaultBankAccounts } = require('../data/mockData');
      
      onUpdateUsers(defaultUsers);
      onUpdateCategories(defaultCategories);
      onUpdateClients(defaultClients);
      onUpdateBankAccounts(defaultBankAccounts);
      
      // Nettoyer le localStorage et sauvegarder les nouvelles données
      localStorage.removeItem('cashflow-users');
      localStorage.removeItem('cashflow-transactions');
      localStorage.removeItem('cashflow-categories');
      localStorage.removeItem('cashflow-clients');
      localStorage.removeItem('cashflow-bank-accounts');
      localStorage.removeItem('cashflow-client-orders');
      
      alert('Toutes les données ont été réinitialisées');
    }
  };

  const tabs = [
    { id: 'categories', label: 'Catégories', icon: Tag },
    { id: 'clients', label: 'Clients', icon: Building2 },
    { id: 'bankAccounts', label: 'Comptes Bancaires', icon: CreditCard },
    { id: 'users', label: 'Utilisateurs', icon: Users },
    { id: 'general', label: 'Général', icon: SettingsIcon },
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg p-4 sm:p-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-6 flex items-center">
        <SettingsIcon className="w-5 h-5 mr-2" />
        Paramètres
      </h2>

      {/* Tabs */}
      <div className="flex space-x-1 mb-6 bg-gray-100 p-1 rounded-lg overflow-x-auto">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center px-4 py-2 rounded-md font-medium transition-all duration-200 text-sm whitespace-nowrap ${
              activeTab === tab.id
                ? 'bg-white text-blue-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-800'
            }`}
          >
            <tab.icon className="w-4 h-4 mr-2" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Categories Tab */}
      {activeTab === 'categories' && (
        <div className="space-y-6">
          {/* Add New Category */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-lg font-medium text-gray-800 mb-4">Ajouter une catégorie</h3>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                <input
                  type="text"
                  placeholder="Nom de la catégorie"
                  value={newCategory.name}
                  onChange={(e) => setNewCategory(prev => ({ ...prev, name: e.target.value }))}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <select
                  value={newCategory.type}
                  onChange={(e) => setNewCategory(prev => ({ ...prev, type: e.target.value as 'income' | 'expense' }))}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="expense">Sortie Argent</option>
                  <option value="income">Entrée Argent</option>
                </select>
                <select
                  value={newCategory.parentCategory}
                  onChange={(e) => setNewCategory(prev => ({ ...prev, parentCategory: e.target.value }))}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Catégorie principale</option>
                  {getParentCategories().filter(cat => cat.type === newCategory.type).map(cat => (
                    <option key={cat.id} value={cat.name}>{cat.name}</option>
                  ))}
                </select>
                <input
                  type="color"
                  value={newCategory.color}
                  onChange={(e) => setNewCategory(prev => ({ ...prev, color: e.target.value }))}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent h-10"
                />
                <button
                  onClick={handleAddCategory}
                  className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors flex items-center justify-center"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Ajouter
                </button>
              </div>
              
              {/* Subcategories */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Sous-catégories</label>
                <div className="flex space-x-2 mb-2">
                  <input
                    type="text"
                    placeholder="Nouvelle sous-catégorie"
                    value={newSubcategory}
                    onChange={(e) => setNewSubcategory(e.target.value)}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    onKeyPress={(e) => e.key === 'Enter' && addSubcategoryToNew()}
                  />
                  <button
                    onClick={addSubcategoryToNew}
                    className="bg-gray-500 text-white px-3 py-2 rounded-lg hover:bg-gray-600 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {newCategory.subcategories.map((sub, index) => (
                    <span
                      key={index}
                      className="bg-blue-100 text-blue-800 px-2 py-1 rounded-md text-sm flex items-center"
                    >
                      {sub}
                      <button
                        onClick={() => removeSubcategoryFromNew(sub)}
                        className="ml-1 text-blue-600 hover:text-blue-800"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Categories Structure */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-gray-800">Structure des catégories</h3>
            
            {/* Sortie Argent */}
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <h4 className="text-lg font-semibold text-red-800 mb-3 flex items-center">
                <div className="w-4 h-4 bg-red-500 rounded-full mr-2"></div>
                Sortie Argent (Dépenses)
              </h4>
              <div className="space-y-2 ml-6">
                {getCategoriesByType('expense').map((category) => (
                  <div key={category.id} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                    <div className="flex items-center space-x-3">
                      <div
                        className="w-4 h-4 rounded-full"
                        style={{ backgroundColor: category.color }}
                      ></div>
                      <div>
                        <p className="font-medium text-gray-800">{category.name}</p>
                        {category.subcategories && (
                          <p className="text-sm text-gray-500">
                            {category.subcategories.length} sous-catégories: {category.subcategories.join(', ')}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => setEditingCategory(category)}
                        className="text-blue-600 hover:text-blue-800"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteCategory(category.id)}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Entrée Argent */}
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <h4 className="text-lg font-semibold text-green-800 mb-3 flex items-center">
                <div className="w-4 h-4 bg-green-500 rounded-full mr-2"></div>
                Entrée Argent (Revenus)
              </h4>
              <div className="space-y-2 ml-6">
                {getCategoriesByType('income').map((category) => (
                  <div key={category.id} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                    <div className="flex items-center space-x-3">
                      <div
                        className="w-4 h-4 rounded-full"
                        style={{ backgroundColor: category.color }}
                      ></div>
                      <div>
                        <p className="font-medium text-gray-800">{category.name}</p>
                        {category.subcategories && (
                          <p className="text-sm text-gray-500">
                            {category.subcategories.length} sous-catégories: {category.subcategories.join(', ')}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => setEditingCategory(category)}
                        className="text-blue-600 hover:text-blue-800"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteCategory(category.id)}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Clients Tab */}
      {activeTab === 'clients' && (
        <div className="space-y-6">
          {/* Add New Client */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-lg font-medium text-gray-800 mb-4">Ajouter un client</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <input
                type="text"
                placeholder="Nom du client"
                value={newClient.name}
                onChange={(e) => setNewClient(prev => ({ ...prev, name: e.target.value }))}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <input
                type="email"
                placeholder="Email"
                value={newClient.email}
                onChange={(e) => setNewClient(prev => ({ ...prev, email: e.target.value }))}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <input
                type="tel"
                placeholder="Téléphone"
                value={newClient.phone}
                onChange={(e) => setNewClient(prev => ({ ...prev, phone: e.target.value }))}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <input
                type="text"
                placeholder="Adresse"
                value={newClient.address}
                onChange={(e) => setNewClient(prev => ({ ...prev, address: e.target.value }))}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <input
                type="number"
                step="0.01"
                placeholder="Balance initiale (TND)"
                value={newClient.balance}
                onChange={(e) => setNewClient(prev => ({ ...prev, balance: parseFloat(e.target.value) || 0 }))}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <button
                onClick={handleAddClient}
                className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors flex items-center justify-center"
              >
                <Plus className="w-4 h-4 mr-2" />
                Ajouter
              </button>
            </div>
          </div>

          {/* Clients List */}
          <div className="space-y-3">
            {clients.map((client) => (
              <div key={client.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                {editingClient?.id === client.id ? (
                  <div className="flex items-center space-x-3 flex-1">
                    <input
                      type="text"
                      value={editingClient.name}
                      onChange={(e) => setEditingClient(prev => prev ? { ...prev, name: e.target.value } : null)}
                      className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                    <input
                      type="email"
                      value={editingClient.email || ''}
                      onChange={(e) => setEditingClient(prev => prev ? { ...prev, email: e.target.value } : null)}
                      className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                    <input
                      type="tel"
                      value={editingClient.phone || ''}
                      onChange={(e) => setEditingClient(prev => prev ? { ...prev, phone: e.target.value } : null)}
                      className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                    <input
                      type="number"
                      step="0.01"
                      value={editingClient.balance}
                      onChange={(e) => setEditingClient(prev => prev ? { ...prev, balance: parseFloat(e.target.value) || 0 } : null)}
                      className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                    <button
                      onClick={() => handleUpdateClient(editingClient)}
                      className="text-green-600 hover:text-green-800"
                    >
                      <Save className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setEditingClient(null)}
                      className="text-gray-600 hover:text-gray-800"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold">
                        <Building2 className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-800">{client.name}</p>
                        <p className="text-sm text-gray-500">
                          {client.email && `${client.email} • `}
                          {client.phone && `${client.phone} • `}
                          {client.address}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className={`font-semibold ${client.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {client.balance.toFixed(2)} TND
                      </span>
                      <button
                        onClick={() => setEditingClient(client)}
                        className="text-blue-600 hover:text-blue-800"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteClient(client.id)}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Bank Accounts Tab */}
      {activeTab === 'bankAccounts' && (
        <div className="space-y-6">
          {/* Add New Bank Account */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-lg font-medium text-gray-800 mb-4">Ajouter un compte bancaire</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <input
                type="text"
                placeholder="Nom du compte"
                value={newBankAccount.name}
                onChange={(e) => setNewBankAccount(prev => ({ ...prev, name: e.target.value }))}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <input
                type="text"
                placeholder="Numéro de compte"
                value={newBankAccount.accountNumber}
                onChange={(e) => setNewBankAccount(prev => ({ ...prev, accountNumber: e.target.value }))}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <input
                type="text"
                placeholder="Nom de la banque"
                value={newBankAccount.bankName}
                onChange={(e) => setNewBankAccount(prev => ({ ...prev, bankName: e.target.value }))}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <input
                type="number"
                step="0.01"
                placeholder="Balance initiale"
                value={newBankAccount.balance}
                onChange={(e) => setNewBankAccount(prev => ({ ...prev, balance: parseFloat(e.target.value) || 0 }))}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <select
                value={newBankAccount.currency}
                onChange={(e) => setNewBankAccount(prev => ({ ...prev, currency: e.target.value }))}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="TND">TND (Dinar Tunisien)</option>
                <option value="EUR">EUR (Euro)</option>
                <option value="USD">USD (Dollar US)</option>
              </select>
              <button
                onClick={handleAddBankAccount}
                className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors flex items-center justify-center"
              >
                <Plus className="w-4 h-4 mr-2" />
                Ajouter
              </button>
            </div>
          </div>

          {/* Bank Accounts List */}
          <div className="space-y-3">
            {bankAccounts.map((account) => (
              <div key={account.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                {editingBankAccount?.id === account.id ? (
                  <div className="flex items-center space-x-3 flex-1">
                    <input
                      type="text"
                      value={editingBankAccount.name}
                      onChange={(e) => setEditingBankAccount(prev => prev ? { ...prev, name: e.target.value } : null)}
                      className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                    <input
                      type="text"
                      value={editingBankAccount.accountNumber}
                      onChange={(e) => setEditingBankAccount(prev => prev ? { ...prev, accountNumber: e.target.value } : null)}
                      className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                    <input
                      type="text"
                      value={editingBankAccount.bankName}
                      onChange={(e) => setEditingBankAccount(prev => prev ? { ...prev, bankName: e.target.value } : null)}
                      className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                    <input
                      type="number"
                      step="0.01"
                      value={editingBankAccount.balance}
                      onChange={(e) => setEditingBankAccount(prev => prev ? { ...prev, balance: parseFloat(e.target.value) || 0 } : null)}
                      className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                    <select
                      value={editingBankAccount.currency}
                      onChange={(e) => setEditingBankAccount(prev => prev ? { ...prev, currency: e.target.value } : null)}
                      className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="TND">TND</option>
                      <option value="EUR">EUR</option>
                      <option value="USD">USD</option>
                    </select>
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={editingBankAccount.isActive}
                        onChange={(e) => setEditingBankAccount(prev => prev ? { ...prev, isActive: e.target.checked } : null)}
                        className="mr-2"
                      />
                      Actif
                    </label>
                    <button
                      onClick={() => handleUpdateBankAccount(editingBankAccount)}
                      className="text-green-600 hover:text-green-800"
                    >
                      <Save className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setEditingBankAccount(null)}
                      className="text-gray-600 hover:text-gray-800"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 rounded-full bg-indigo-500 flex items-center justify-center text-white font-bold">
                        <CreditCard className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-800">{account.name}</p>
                        <p className="text-sm text-gray-500">
                          {account.bankName} • {account.accountNumber}
                          {!account.isActive && ' • Inactif'}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className={`font-semibold ${account.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {account.balance.toFixed(2)} {account.currency}
                      </span>
                      <button
                        onClick={() => setEditingBankAccount(account)}
                        className="text-blue-600 hover:text-blue-800"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteBankAccount(account.id)}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Users Tab */}
      {activeTab === 'users' && (
        <div className="space-y-6">
          {/* Add New User */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-lg font-medium text-gray-800 mb-4">Ajouter un utilisateur</h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <input
                type="text"
                placeholder="Nom de l'utilisateur"
                value={newUser.name}
                onChange={(e) => setNewUser(prev => ({ ...prev, name: e.target.value }))}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <select
                value={newUser.role}
                onChange={(e) => setNewUser(prev => ({ ...prev, role: e.target.value as 'admin' | 'user' }))}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="user">Utilisateur</option>
                <option value="admin">Administrateur</option>
              </select>
              <input
                type="number"
                step="0.01"
                placeholder="Balance initiale (TND)"
                value={newUser.balance}
                onChange={(e) => setNewUser(prev => ({ ...prev, balance: parseFloat(e.target.value) || 0 }))}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <button
                onClick={handleAddUser}
                className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors flex items-center justify-center"
              >
                <Plus className="w-4 h-4 mr-2" />
                Ajouter
              </button>
            </div>
          </div>

          {/* Users List */}
          <div className="space-y-3">
            {users.map((user) => (
              <div key={user.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                {editingUser?.id === user.id ? (
                  <div className="flex items-center space-x-3 flex-1">
                    <input
                      type="text"
                      value={editingUser.name}
                      onChange={(e) => setEditingUser(prev => prev ? { ...prev, name: e.target.value } : null)}
                      className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                    <select
                      value={editingUser.role}
                      onChange={(e) => setEditingUser(prev => prev ? { ...prev, role: e.target.value as 'admin' | 'user' } : null)}
                      className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="user">Utilisateur</option>
                      <option value="admin">Administrateur</option>
                    </select>
                    <input
                      type="number"
                      step="0.01"
                      value={editingUser.balance}
                      onChange={(e) => setEditingUser(prev => prev ? { ...prev, balance: parseFloat(e.target.value) || 0 } : null)}
                      className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                    <button
                      onClick={() => handleUpdateUser(editingUser)}
                      className="text-green-600 hover:text-green-800"
                    >
                      <Save className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setEditingUser(null)}
                      className="text-gray-600 hover:text-gray-800"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold ${
                        user.role === 'admin' ? 'bg-blue-500' : 'bg-gray-500'
                      }`}>
                        {user.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-medium text-gray-800">{user.name}</p>
                        <p className="text-sm text-gray-500 capitalize">{user.role}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className={`font-semibold ${user.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {user.balance.toFixed(2)} TND
                      </span>
                      <button
                        onClick={() => setEditingUser(user)}
                        className="text-blue-600 hover:text-blue-800"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteUser(user.id)}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* General Tab */}
      {activeTab === 'general' && (
        <div className="space-y-6">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-lg font-medium text-gray-800 mb-4">Paramètres généraux</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Devise par défaut
                </label>
                <input
                  type="text"
                  value="TND (Dinar Tunisien)"
                  disabled
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-100 text-gray-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Format de date
                </label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                  <option value="fr-FR">DD/MM/YYYY (Français)</option>
                  <option value="en-US">MM/DD/YYYY (Anglais)</option>
                  <option value="iso">YYYY-MM-DD (ISO)</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Sauvegarde automatique
                </label>
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    checked={true}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <span className="ml-2 text-sm text-gray-700">
                    Sauvegarder automatiquement les données dans le navigateur
                  </span>
                </div>
              </div>

              <div className="pt-4 border-t border-gray-200">
                <h4 className="text-md font-medium text-gray-800 mb-3">Actions de données</h4>
                <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <h5 className="font-medium text-blue-800 mb-2">Configuration Base de Données</h5>
                  <p className="text-sm text-blue-600 mb-2">
                    Pour utiliser Supabase, configurez vos variables d'environnement :
                  </p>
                  <div className="bg-blue-100 p-2 rounded text-xs font-mono text-blue-800">
                    VITE_SUPABASE_URL=your_supabase_url<br/>
                    VITE_SUPABASE_ANON_KEY=your_supabase_key
                  </div>
                  <p className="text-xs text-blue-600 mt-2">
                    Sans configuration, l'app utilise le stockage local (localStorage)
                  </p>
                </div>
                <div className="flex flex-wrap gap-3">
                  <button 
                    onClick={handleExportData}
                    className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition-colors"
                  >
                    Exporter les données
                  </button>
                  <label className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors cursor-pointer">
                    Importer les données
                    <input
                      type="file"
                      accept=".json"
                      onChange={handleImportData}
                      className="hidden"
                    />
                  </label>
                  <button 
                    onClick={handleResetData}
                    className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors"
                  >
                    Réinitialiser toutes les données
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};