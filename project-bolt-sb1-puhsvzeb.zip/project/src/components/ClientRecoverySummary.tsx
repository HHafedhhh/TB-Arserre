import React, { useState } from 'react';
import { TrendingUp, DollarSign, Users, Calendar, FileText, Building2, CreditCard, AlertCircle, CheckCircle } from 'lucide-react';
import { Transaction, Client, ClientOrder, ClientRecoverySummary as ClientRecoverySummaryType } from '../types';

interface ClientRecoverySummaryProps {
  transactions: Transaction[];
  clients: Client[];
  orders: ClientOrder[];
}

export const ClientRecoverySummary: React.FC<ClientRecoverySummaryProps> = ({ transactions, clients, orders }) => {
  const [selectedClient, setSelectedClient] = useState<string>('');
  const [dateRange, setDateRange] = useState({
    startDate: '',
    endDate: ''
  });

  const generateClientSummary = (clientId: string): ClientRecoverySummaryType => {
    const client = clients.find(c => c.id === clientId);
    const clientOrders = orders.filter(o => o.clientId === clientId);
    const clientRecoveries = transactions.filter(t => 
      t.type === 'income' && 
      t.category === 'Recouvrement Client' && 
      t.clientId === clientId
    );

    // Apply date filters if set
    const filteredRecoveries = clientRecoveries.filter(t => {
      if (dateRange.startDate && t.date < new Date(dateRange.startDate)) return false;
      if (dateRange.endDate && t.date > new Date(dateRange.endDate)) return false;
      return true;
    });

    const totalOrderAmount = clientOrders.reduce((sum, order) => sum + order.amount, 0);
    const totalRecovered = filteredRecoveries.reduce((sum, recovery) => sum + recovery.amount, 0);
    const totalPending = totalOrderAmount - totalRecovered;
    const recoveryRate = totalOrderAmount > 0 ? (totalRecovered / totalOrderAmount) * 100 : 0;
    
    const lastRecovery = filteredRecoveries.sort((a, b) => b.date.getTime() - a.date.getTime())[0];

    return {
      clientId,
      clientName: client?.name || 'Client inconnu',
      totalOrders: clientOrders.length,
      totalOrderAmount,
      totalRecovered,
      totalPending,
      recoveryRate,
      lastRecoveryDate: lastRecovery?.date,
      orders: clientOrders,
      recoveries: filteredRecoveries
    };
  };

  const getAllClientsSummary = (): ClientRecoverySummaryType[] => {
    return clients.map(client => generateClientSummary(client.id));
  };

  const getOverallStats = () => {
    const allSummaries = getAllClientsSummary();
    return {
      totalClients: clients.length,
      totalOrders: allSummaries.reduce((sum, s) => sum + s.totalOrders, 0),
      totalOrderAmount: allSummaries.reduce((sum, s) => sum + s.totalOrderAmount, 0),
      totalRecovered: allSummaries.reduce((sum, s) => sum + s.totalRecovered, 0),
      totalPending: allSummaries.reduce((sum, s) => sum + s.totalPending, 0),
      averageRecoveryRate: allSummaries.length > 0 
        ? allSummaries.reduce((sum, s) => sum + s.recoveryRate, 0) / allSummaries.length 
        : 0
    };
  };

  const overallStats = getOverallStats();
  const clientSummaries = getAllClientsSummary().sort((a, b) => b.totalOrderAmount - a.totalOrderAmount);
  const selectedSummary = selectedClient ? generateClientSummary(selectedClient) : null;

  const getRecoveryRateColor = (rate: number) => {
    if (rate >= 80) return 'text-green-600 bg-green-50 border-green-200';
    if (rate >= 50) return 'text-yellow-600 bg-yellow-50 border-yellow-200';
    return 'text-red-600 bg-red-50 border-red-200';
  };

  const getRecoveryRateIcon = (rate: number) => {
    if (rate >= 80) return <CheckCircle className="w-4 h-4" />;
    if (rate >= 50) return <AlertCircle className="w-4 h-4" />;
    return <AlertCircle className="w-4 h-4" />;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h2 className="text-xl font-semibold text-gray-800 mb-6 flex items-center">
          <TrendingUp className="w-5 h-5 mr-2" />
          Synthèse Recouvrement Clients
        </h2>

        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <select
            value={selectedClient}
            onChange={(e) => setSelectedClient(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">Tous les clients</option>
            {clients.map(client => (
              <option key={client.id} value={client.id}>{client.name}</option>
            ))}
          </select>
          <input
            type="date"
            value={dateRange.startDate}
            onChange={(e) => setDateRange(prev => ({ ...prev, startDate: e.target.value }))}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Date de début"
          />
          <input
            type="date"
            value={dateRange.endDate}
            onChange={(e) => setDateRange(prev => ({ ...prev, endDate: e.target.value }))}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Date de fin"
          />
        </div>

        {/* Overall Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-600 text-sm font-medium">Total Commandes</p>
                <p className="text-blue-800 text-2xl font-bold">{overallStats.totalOrderAmount.toFixed(2)} TND</p>
                <p className="text-blue-600 text-xs">{overallStats.totalOrders} commandes</p>
              </div>
              <FileText className="w-8 h-8 text-blue-500" />
            </div>
          </div>
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-600 text-sm font-medium">Total Recouvré</p>
                <p className="text-green-800 text-2xl font-bold">{overallStats.totalRecovered.toFixed(2)} TND</p>
                <p className="text-green-600 text-xs">{overallStats.averageRecoveryRate.toFixed(1)}% en moyenne</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
          </div>
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-red-600 text-sm font-medium">En Attente</p>
                <p className="text-red-800 text-2xl font-bold">{overallStats.totalPending.toFixed(2)} TND</p>
                <p className="text-red-600 text-xs">À recouvrer</p>
              </div>
              <AlertCircle className="w-8 h-8 text-red-500" />
            </div>
          </div>
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-600 text-sm font-medium">Clients Actifs</p>
                <p className="text-purple-800 text-2xl font-bold">{overallStats.totalClients}</p>
                <p className="text-purple-600 text-xs">Clients enregistrés</p>
              </div>
              <Users className="w-8 h-8 text-purple-500" />
            </div>
          </div>
        </div>
      </div>

      {/* Client Detail View */}
      {selectedSummary && (
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
            <Building2 className="w-5 h-5 mr-2" />
            Détail Client: {selectedSummary.clientName}
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-gray-600 text-sm">Commandes</p>
              <p className="text-gray-800 text-xl font-bold">{selectedSummary.totalOrders}</p>
            </div>
            <div className="bg-blue-50 rounded-lg p-4">
              <p className="text-blue-600 text-sm">Montant Total</p>
              <p className="text-blue-800 text-xl font-bold">{selectedSummary.totalOrderAmount.toFixed(2)} TND</p>
            </div>
            <div className="bg-green-50 rounded-lg p-4">
              <p className="text-green-600 text-sm">Recouvré</p>
              <p className="text-green-800 text-xl font-bold">{selectedSummary.totalRecovered.toFixed(2)} TND</p>
            </div>
            <div className={`rounded-lg p-4 border ${getRecoveryRateColor(selectedSummary.recoveryRate)}`}>
              <p className="text-sm flex items-center">
                {getRecoveryRateIcon(selectedSummary.recoveryRate)}
                <span className="ml-1">Taux de Recouvrement</span>
              </p>
              <p className="text-xl font-bold">{selectedSummary.recoveryRate.toFixed(1)}%</p>
            </div>
          </div>

          {/* Recent Recoveries */}
          <div className="mb-6">
            <h4 className="text-md font-semibold text-gray-800 mb-3">Recouvrements Récents</h4>
            <div className="space-y-2">
              {selectedSummary.recoveries.slice(0, 5).map((recovery) => (
                <div key={recovery.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                      +
                    </div>
                    <div>
                      <p className="font-medium text-gray-800">{recovery.description}</p>
                      <p className="text-sm text-gray-500 flex items-center">
                        <Calendar className="w-3 h-3 mr-1" />
                        {recovery.date.toLocaleDateString('fr-FR')}
                        {recovery.subcategory && ` • ${recovery.subcategory}`}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-green-600">+{recovery.amount.toFixed(2)} TND</p>
                  </div>
                </div>
              ))}
              {selectedSummary.recoveries.length === 0 && (
                <p className="text-gray-500 text-center py-4">Aucun recouvrement enregistré</p>
              )}
            </div>
          </div>

          {/* Client Orders */}
          <div>
            <h4 className="text-md font-semibold text-gray-800 mb-3">Commandes du Client</h4>
            <div className="space-y-2">
              {selectedSummary.orders.map((order) => (
                <div key={order.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold ${
                      order.status === 'delivered' ? 'bg-green-500' : 
                      order.status === 'received' ? 'bg-yellow-500' : 'bg-gray-500'
                    }`}>
                      {order.status === 'delivered' ? '✓' : order.status === 'received' ? '⏳' : '📦'}
                    </div>
                    <div>
                      <p className="font-medium text-gray-800">{order.orderNumber}</p>
                      <p className="text-sm text-gray-500">{order.description}</p>
                      <p className="text-xs text-gray-400 flex items-center">
                        <Calendar className="w-3 h-3 mr-1" />
                        Reçue: {order.receivedDate.toLocaleDateString('fr-FR')}
                        {order.deliveredDate && ` • Livrée: ${order.deliveredDate.toLocaleDateString('fr-FR')}`}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-blue-600">{order.amount.toFixed(2)} TND</p>
                    <p className={`text-xs px-2 py-1 rounded-full ${
                      order.status === 'delivered' ? 'bg-green-100 text-green-800' : 
                      order.status === 'received' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {order.status === 'delivered' ? 'Livrée' : 
                       order.status === 'received' ? 'Reçue' : 'Archivée'}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* All Clients Summary */}
      {!selectedClient && (
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-800">Synthèse par Client</h3>
          </div>
          <div className="max-h-[60vh] overflow-y-auto">
            <div className="divide-y divide-gray-100">
              {clientSummaries.map((summary) => (
                <div key={summary.clientId} className="p-6 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold">
                        <Building2 className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-800">{summary.clientName}</h4>
                        <p className="text-sm text-gray-500">{summary.totalOrders} commandes</p>
                      </div>
                    </div>
                    <button
                      onClick={() => setSelectedClient(summary.clientId)}
                      className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors text-sm"
                    >
                      Voir détails
                    </button>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center">
                      <p className="text-sm text-gray-600">Total Commandes</p>
                      <p className="text-lg font-bold text-blue-600">{summary.totalOrderAmount.toFixed(2)} TND</p>
                    </div>
                    <div className="text-center">
                      <p className="text-sm text-gray-600">Recouvré</p>
                      <p className="text-lg font-bold text-green-600">{summary.totalRecovered.toFixed(2)} TND</p>
                    </div>
                    <div className="text-center">
                      <p className="text-sm text-gray-600">En Attente</p>
                      <p className="text-lg font-bold text-red-600">{summary.totalPending.toFixed(2)} TND</p>
                    </div>
                    <div className="text-center">
                      <p className="text-sm text-gray-600">Taux</p>
                      <p className={`text-lg font-bold ${
                        summary.recoveryRate >= 80 ? 'text-green-600' : 
                        summary.recoveryRate >= 50 ? 'text-yellow-600' : 'text-red-600'
                      }`}>
                        {summary.recoveryRate.toFixed(1)}%
                      </p>
                    </div>
                  </div>

                  {summary.lastRecoveryDate && (
                    <div className="mt-3 text-sm text-gray-500 flex items-center">
                      <Calendar className="w-4 h-4 mr-1" />
                      Dernier recouvrement: {summary.lastRecoveryDate.toLocaleDateString('fr-FR')}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};