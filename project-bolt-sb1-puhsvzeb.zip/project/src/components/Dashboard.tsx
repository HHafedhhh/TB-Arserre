import React from 'react';
import { TrendingUp, TrendingDown, Users, ArrowLeftRight, Wallet, Building2, CreditCard, AlertTriangle } from 'lucide-react';
import { Transaction, User, Client, BankAccount } from '../types';

interface DashboardProps {
  users: User[];
  transactions: Transaction[];
  clients: Client[];
  bankAccounts: BankAccount[];
}

export const Dashboard: React.FC<DashboardProps> = ({ users, transactions, clients, bankAccounts }) => {
  const totalBalance = users.reduce((sum, user) => sum + user.balance, 0);
  const totalIncome = transactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);
  const totalExpenses = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);
  
  // Calculer le crédit client (montant non payé par les clients)
  const totalClientCredit = clients.reduce((sum, client) => {
    // Les balances négatives des clients représentent ce qu'ils doivent
    return sum + (client.balance < 0 ? Math.abs(client.balance) : 0);
  }, 0);
  
  const bankAccountsBalance = bankAccounts.reduce((sum, account) => sum + account.balance, 0);

  const stats = [
    {
      title: 'Balance Totale',
      value: `${totalBalance.toFixed(2)} TND`,
      icon: Wallet,
      color: 'bg-gradient-to-r from-blue-500 to-blue-600',
      textColor: 'text-white'
    },
    {
      title: 'Entrées Argent',
      value: `${totalIncome.toFixed(2)} TND`,
      icon: TrendingUp,
      color: 'bg-gradient-to-r from-green-500 to-green-600',
      textColor: 'text-white'
    },
    {
      title: 'Sorties Argent',
      value: `${totalExpenses.toFixed(2)} TND`,
      icon: TrendingDown,
      color: 'bg-gradient-to-r from-red-500 to-red-600',
      textColor: 'text-white'
    },
    {
      title: 'Crédit Client',
      value: `${totalClientCredit.toFixed(2)} TND`,
      icon: AlertTriangle,
      color: 'bg-gradient-to-r from-purple-500 to-purple-600',
      textColor: 'text-white'
    }
  ];

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6">
        {stats.map((stat) => (
          <div key={stat.title} className={`${stat.color} rounded-xl p-4 sm:p-6 shadow-lg transform hover:scale-105 transition-transform duration-200`}>
            <div className="flex items-center justify-between">
              <div className="min-w-0 flex-1">
                <p className={`${stat.textColor} text-xs sm:text-sm font-medium opacity-90 truncate`}>{stat.title}</p>
                <p className={`${stat.textColor} text-lg sm:text-2xl font-bold mt-1 truncate`}>{stat.value}</p>
              </div>
              <stat.icon className={`${stat.textColor} w-6 h-6 sm:w-8 sm:h-8 opacity-80 flex-shrink-0 ml-2`} />
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 sm:gap-6">
        <div className="bg-white rounded-xl shadow-lg p-4 sm:p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base sm:text-lg font-semibold text-gray-800">Utilisateurs</h3>
            <Users className="w-4 h-4 sm:w-5 sm:h-5 text-gray-500" />
          </div>
          <div className="space-y-3 sm:space-y-4">
            {users.map((user) => (
              <div key={user.id} className="flex items-center justify-between p-3 sm:p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <div className="flex items-center space-x-3 min-w-0 flex-1">
                  <div className={`w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center text-white font-semibold text-sm flex-shrink-0 ${
                    user.role === 'admin' ? 'bg-gradient-to-r from-blue-500 to-blue-600' : 'bg-gradient-to-r from-gray-500 to-gray-600'
                  }`}>
                    {user.name.charAt(0)}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="font-medium text-gray-800 text-sm sm:text-base truncate">{user.name}</p>
                    <p className="text-xs sm:text-sm text-gray-500 capitalize">{user.role}</p>
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className={`font-semibold text-sm sm:text-base ${user.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {user.balance.toFixed(2)} TND
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-4 sm:p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base sm:text-lg font-semibold text-gray-800">Comptes Bancaires</h3>
            <CreditCard className="w-4 h-4 sm:w-5 sm:h-5 text-gray-500" />
          </div>
          <div className="space-y-3 sm:space-y-4">
            {bankAccounts.slice(0, 5).map((account) => (
              <div key={account.id} className="flex items-center justify-between p-3 sm:p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <div className="flex items-center space-x-3 min-w-0 flex-1">
                  <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-indigo-500 flex items-center justify-center text-white font-semibold text-sm flex-shrink-0">
                    <CreditCard className="w-4 h-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="font-medium text-gray-800 text-sm sm:text-base truncate">{account.name}</p>
                    <p className="text-xs sm:text-sm text-gray-500 truncate">{account.bankName}</p>
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className={`font-semibold text-sm sm:text-base ${account.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {account.balance.toFixed(2)} {account.currency}
                  </p>
                </div>
              </div>
            ))}
            {bankAccounts.length === 0 && (
              <p className="text-gray-500 text-center py-4">Aucun compte bancaire enregistré</p>
            )}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-4 sm:p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base sm:text-lg font-semibold text-gray-800">Clients</h3>
            <Building2 className="w-4 h-4 sm:w-5 sm:h-5 text-gray-500" />
          </div>
          <div className="space-y-3 sm:space-y-4">
            {clients.slice(0, 5).map((client) => (
              <div key={client.id} className="flex items-center justify-between p-3 sm:p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <div className="flex items-center space-x-3 min-w-0 flex-1">
                  <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-blue-500 flex items-center justify-center text-white font-semibold text-sm flex-shrink-0">
                    <Building2 className="w-4 h-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="font-medium text-gray-800 text-sm sm:text-base truncate">{client.name}</p>
                    <p className="text-xs sm:text-sm text-gray-500 truncate">{client.email || 'Pas d\'email'}</p>
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className={`font-semibold text-sm sm:text-base ${client.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {client.balance.toFixed(2)} TND
                  </p>
                  {client.balance < 0 && (
                    <p className="text-xs text-purple-600 font-medium">
                      Doit: {Math.abs(client.balance).toFixed(2)} TND
                    </p>
                  )}
                </div>
              </div>
            ))}
            {clients.length === 0 && (
              <p className="text-gray-500 text-center py-4">Aucun client enregistré</p>
            )}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-4 sm:p-6">
          <h3 className="text-base sm:text-lg font-semibold text-gray-800 mb-4">Transactions Récentes</h3>
          <div className="space-y-3 sm:space-y-4">
            {transactions.slice(0, 5).map((transaction) => (
              <div key={transaction.id} className="flex items-center justify-between p-3 sm:p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3 min-w-0 flex-1">
                  <div className={`w-6 h-6 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-white text-xs sm:text-sm font-semibold flex-shrink-0 ${
                    transaction.type === 'income' ? 'bg-green-500' : 
                    transaction.type === 'expense' ? 'bg-red-500' : 'bg-purple-500'
                  }`}>
                    {transaction.type === 'income' ? '+' : transaction.type === 'expense' ? '-' : '↔'}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="font-medium text-gray-800 text-sm sm:text-base truncate">{transaction.description}</p>
                    <p className="text-xs sm:text-sm text-gray-500 truncate">{transaction.category}</p>
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className={`font-semibold text-sm sm:text-base ${
                    transaction.type === 'income' ? 'text-green-600' : 
                    transaction.type === 'expense' ? 'text-red-600' : 'text-purple-600'
                  }`}>
                    {transaction.type === 'income' ? '+' : transaction.type === 'expense' ? '-' : ''}
                    {transaction.amount.toFixed(2)} TND
                  </p>
                  <p className="text-xs sm:text-sm text-gray-500">
                    {new Date(transaction.date).toLocaleDateString('fr-FR')}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};