import React, { useState } from 'react';
import { Package, Plus, Edit2, Trash2, Save, X, Calendar, FileText, DollarSign, Archive, CheckCircle, Clock } from 'lucide-react';
import { ClientOrder, Client } from '../types';

interface ClientOrdersProps {
  orders: ClientOrder[];
  clients: Client[];
  onUpdateOrders: (orders: ClientOrder[]) => void;
}

export const ClientOrders: React.FC<ClientOrdersProps> = ({ orders, clients, onUpdateOrders }) => {
  const [editingOrder, setEditingOrder] = useState<ClientOrder | null>(null);
  const [newOrder, setNewOrder] = useState({
    clientId: '',
    orderNumber: '',
    description: '',
    amount: 0,
    status: 'received' as 'received' | 'delivered' | 'archived',
    receivedDate: new Date().toISOString().split('T')[0],
    deliveredDate: '',
    notes: ''
  });
  const [filterStatus, setFilterStatus] = useState<'all' | 'received' | 'delivered' | 'archived'>('all');
  const [filterClient, setFilterClient] = useState('');

  const handleAddOrder = () => {
    if (!newOrder.clientId || !newOrder.orderNumber || !newOrder.description || !newOrder.amount) return;

    const order: ClientOrder = {
      id: Date.now().toString(),
      clientId: newOrder.clientId,
      orderNumber: newOrder.orderNumber,
      description: newOrder.description,
      amount: newOrder.amount,
      status: newOrder.status,
      receivedDate: new Date(newOrder.receivedDate),
      deliveredDate: newOrder.deliveredDate ? new Date(newOrder.deliveredDate) : undefined,
      archivedDate: newOrder.status === 'archived' ? new Date() : undefined,
      notes: newOrder.notes || undefined,
      createdAt: new Date()
    };

    onUpdateOrders([...orders, order]);
    setNewOrder({
      clientId: '',
      orderNumber: '',
      description: '',
      amount: 0,
      status: 'received',
      receivedDate: new Date().toISOString().split('T')[0],
      deliveredDate: '',
      notes: ''
    });
  };

  const handleUpdateOrder = (updatedOrder: ClientOrder) => {
    const updated = {
      ...updatedOrder,
      deliveredDate: updatedOrder.status === 'delivered' && !updatedOrder.deliveredDate ? new Date() : updatedOrder.deliveredDate,
      archivedDate: updatedOrder.status === 'archived' && !updatedOrder.archivedDate ? new Date() : updatedOrder.archivedDate
    };

    onUpdateOrders(orders.map(order => order.id === updated.id ? updated : order));
    setEditingOrder(null);
  };

  const handleDeleteOrder = (orderId: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cette commande ?')) {
      onUpdateOrders(orders.filter(order => order.id !== orderId));
    }
  };

  const getClientName = (clientId: string) => {
    const client = clients.find(c => c.id === clientId);
    return client ? client.name : 'Client inconnu';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'received': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'delivered': return 'bg-green-100 text-green-800 border-green-200';
      case 'archived': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'received': return <Clock className="w-4 h-4" />;
      case 'delivered': return <CheckCircle className="w-4 h-4" />;
      case 'archived': return <Archive className="w-4 h-4" />;
      default: return <Package className="w-4 h-4" />;
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'received': return 'Reçue';
      case 'delivered': return 'Livrée';
      case 'archived': return 'Archivée';
      default: return status;
    }
  };

  const filteredOrders = orders.filter(order => {
    if (filterStatus !== 'all' && order.status !== filterStatus) return false;
    if (filterClient && order.clientId !== filterClient) return false;
    return true;
  });

  const totalOrders = filteredOrders.length;
  const totalAmount = filteredOrders.reduce((sum, order) => sum + order.amount, 0);

  return (
    <div className="space-y-6">
      {/* Header with Stats */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-800 flex items-center">
            <Package className="w-5 h-5 mr-2" />
            Gestion des Commandes Clients
          </h2>
          <div className="flex items-center space-x-4 text-sm">
            <div className="bg-blue-50 px-3 py-2 rounded-lg">
              <span className="text-blue-600 font-medium">{totalOrders} commandes</span>
            </div>
            <div className="bg-green-50 px-3 py-2 rounded-lg">
              <span className="text-green-600 font-medium">{totalAmount.toFixed(2)} TND</span>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-yellow-600 text-sm font-medium">Commandes Reçues</p>
                <p className="text-yellow-800 text-2xl font-bold">
                  {orders.filter(o => o.status === 'received').length}
                </p>
              </div>
              <Clock className="w-8 h-8 text-yellow-500" />
            </div>
          </div>
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-600 text-sm font-medium">Commandes Livrées</p>
                <p className="text-green-800 text-2xl font-bold">
                  {orders.filter(o => o.status === 'delivered').length}
                </p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
          </div>
          <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-medium">Commandes Archivées</p>
                <p className="text-gray-800 text-2xl font-bold">
                  {orders.filter(o => o.status === 'archived').length}
                </p>
              </div>
              <Archive className="w-8 h-8 text-gray-500" />
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4 mb-6">
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value as any)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">Tous les statuts</option>
            <option value="received">Reçues</option>
            <option value="delivered">Livrées</option>
            <option value="archived">Archivées</option>
          </select>
          <select
            value={filterClient}
            onChange={(e) => setFilterClient(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">Tous les clients</option>
            {clients.map(client => (
              <option key={client.id} value={client.id}>{client.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Add New Order */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
          <Plus className="w-5 h-5 mr-2" />
          Nouvelle Commande
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <select
            value={newOrder.clientId}
            onChange={(e) => setNewOrder(prev => ({ ...prev, clientId: e.target.value }))}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">Sélectionner un client</option>
            {clients.map(client => (
              <option key={client.id} value={client.id}>{client.name}</option>
            ))}
          </select>
          <input
            type="text"
            placeholder="Numéro de commande"
            value={newOrder.orderNumber}
            onChange={(e) => setNewOrder(prev => ({ ...prev, orderNumber: e.target.value }))}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <input
            type="text"
            placeholder="Description"
            value={newOrder.description}
            onChange={(e) => setNewOrder(prev => ({ ...prev, description: e.target.value }))}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <input
            type="number"
            step="0.01"
            placeholder="Montant (TND)"
            value={newOrder.amount}
            onChange={(e) => setNewOrder(prev => ({ ...prev, amount: parseFloat(e.target.value) || 0 }))}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <select
            value={newOrder.status}
            onChange={(e) => setNewOrder(prev => ({ ...prev, status: e.target.value as any }))}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="received">Reçue</option>
            <option value="delivered">Livrée</option>
            <option value="archived">Archivée</option>
          </select>
          <input
            type="date"
            value={newOrder.receivedDate}
            onChange={(e) => setNewOrder(prev => ({ ...prev, receivedDate: e.target.value }))}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        <div className="mt-4">
          <textarea
            placeholder="Notes (optionnel)"
            value={newOrder.notes}
            onChange={(e) => setNewOrder(prev => ({ ...prev, notes: e.target.value }))}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            rows={2}
          />
        </div>
        <button
          onClick={handleAddOrder}
          className="mt-4 bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600 transition-colors flex items-center"
        >
          <Plus className="w-4 h-4 mr-2" />
          Ajouter la Commande
        </button>
      </div>

      {/* Orders List */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="max-h-[60vh] overflow-y-auto">
          {filteredOrders.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <Package className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p className="text-lg font-medium mb-2">Aucune commande trouvée</p>
              <p className="text-sm">Ajoutez une nouvelle commande ou modifiez vos filtres</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {filteredOrders.map((order) => (
                <div key={order.id} className="p-6 hover:bg-gray-50 transition-colors">
                  {editingOrder?.id === order.id ? (
                    // Edit Mode
                    <div className="space-y-4">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold text-gray-800">Modifier la commande</h3>
                        <div className={`px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(editingOrder.status)}`}>
                          {getStatusIcon(editingOrder.status)}
                          <span className="ml-1">{getStatusLabel(editingOrder.status)}</span>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <select
                          value={editingOrder.clientId}
                          onChange={(e) => setEditingOrder(prev => prev ? { ...prev, clientId: e.target.value } : null)}
                          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        >
                          {clients.map(client => (
                            <option key={client.id} value={client.id}>{client.name}</option>
                          ))}
                        </select>
                        <input
                          type="text"
                          value={editingOrder.orderNumber}
                          onChange={(e) => setEditingOrder(prev => prev ? { ...prev, orderNumber: e.target.value } : null)}
                          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                        <input
                          type="text"
                          value={editingOrder.description}
                          onChange={(e) => setEditingOrder(prev => prev ? { ...prev, description: e.target.value } : null)}
                          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                        <input
                          type="number"
                          step="0.01"
                          value={editingOrder.amount}
                          onChange={(e) => setEditingOrder(prev => prev ? { ...prev, amount: parseFloat(e.target.value) || 0 } : null)}
                          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                        <select
                          value={editingOrder.status}
                          onChange={(e) => setEditingOrder(prev => prev ? { ...prev, status: e.target.value as any } : null)}
                          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        >
                          <option value="received">Reçue</option>
                          <option value="delivered">Livrée</option>
                          <option value="archived">Archivée</option>
                        </select>
                        <input
                          type="date"
                          value={editingOrder.receivedDate.toISOString().split('T')[0]}
                          onChange={(e) => setEditingOrder(prev => prev ? { ...prev, receivedDate: new Date(e.target.value) } : null)}
                          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>

                      <textarea
                        value={editingOrder.notes || ''}
                        onChange={(e) => setEditingOrder(prev => prev ? { ...prev, notes: e.target.value } : null)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        rows={2}
                        placeholder="Notes"
                      />

                      <div className="flex space-x-3">
                        <button
                          onClick={() => handleUpdateOrder(editingOrder)}
                          className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition-colors flex items-center"
                        >
                          <Save className="w-4 h-4 mr-2" />
                          Sauvegarder
                        </button>
                        <button
                          onClick={() => setEditingOrder(null)}
                          className="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600 transition-colors flex items-center"
                        >
                          <X className="w-4 h-4 mr-2" />
                          Annuler
                        </button>
                      </div>
                    </div>
                  ) : (
                    // View Mode
                    <div>
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="text-lg font-semibold text-gray-800">{order.orderNumber}</h3>
                            <div className={`px-3 py-1 rounded-full text-sm font-medium border flex items-center ${getStatusColor(order.status)}`}>
                              {getStatusIcon(order.status)}
                              <span className="ml-1">{getStatusLabel(order.status)}</span>
                            </div>
                          </div>
                          <p className="text-gray-600 mb-2">{order.description}</p>
                          <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500">
                            <span className="flex items-center">
                              <Calendar className="w-4 h-4 mr-1" />
                              Reçue: {order.receivedDate.toLocaleDateString('fr-FR')}
                            </span>
                            {order.deliveredDate && (
                              <span className="flex items-center">
                                <CheckCircle className="w-4 h-4 mr-1" />
                                Livrée: {order.deliveredDate.toLocaleDateString('fr-FR')}
                              </span>
                            )}
                            <span className="flex items-center">
                              <DollarSign className="w-4 h-4 mr-1" />
                              {order.amount.toFixed(2)} TND
                            </span>
                          </div>
                          {order.notes && (
                            <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                              <p className="text-sm text-gray-600 flex items-start">
                                <FileText className="w-4 h-4 mr-1 mt-0.5 flex-shrink-0" />
                                {order.notes}
                              </p>
                            </div>
                          )}
                        </div>
                        <div className="flex flex-col items-end space-y-2 ml-4">
                          <p className="text-sm font-medium text-gray-600">{getClientName(order.clientId)}</p>
                          <p className="text-xl font-bold text-blue-600">{order.amount.toFixed(2)} TND</p>
                          <div className="flex space-x-2">
                            <button
                              onClick={() => setEditingOrder(order)}
                              className="bg-blue-500 text-white px-3 py-1 rounded text-sm hover:bg-blue-600 transition-colors flex items-center"
                            >
                              <Edit2 className="w-3 h-3 mr-1" />
                              Modifier
                            </button>
                            <button
                              onClick={() => handleDeleteOrder(order.id)}
                              className="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600 transition-colors flex items-center"
                            >
                              <Trash2 className="w-3 h-3 mr-1" />
                              Supprimer
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};