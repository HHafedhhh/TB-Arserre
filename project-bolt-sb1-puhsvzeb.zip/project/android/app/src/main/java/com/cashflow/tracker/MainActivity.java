package com.cashflow.tracker;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
